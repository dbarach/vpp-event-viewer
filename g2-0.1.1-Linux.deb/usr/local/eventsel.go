package g2

import (
	"std"
	"ui/gtk"
)

type eventsel_main_t struct {
	event_id_by_button  map[gtk.Widget]int
	buttons             []gtk.ToggleButton
	first_visible_index uint
	vbox                gtk.Box
	hbox                gtk.Box
}

var eventsel_main eventsel_main_t

func select_toggle(w gtk.Widget, o gtk.Opaque) {
	fc := &g2_main.current_file
	event_code := eventsel_main.event_id_by_button[w]
	event_definition := &fc.event_definitions.Vec[event_code]
	event_definition.is_displayed = !event_definition.is_displayed
	v := &g2_main.v
	v.repaint()
}

func select_all_events(w gtk.Widget, o gtk.Opaque) {
	for i := range eventsel_main.buttons {
		b := eventsel_main.buttons[i]
		b.SetActive(true)
	}
}
func select_no_events(w gtk.Widget, o gtk.Opaque) {
	for i := range eventsel_main.buttons {
		b := eventsel_main.buttons[i]
		b.SetActive(false)
	}
}

func up_button_clicked(w gtk.Widget, o gtk.Opaque) {
	em := &eventsel_main
	v := &g2_main.v
	if em.first_visible_index >= v.max_event_selector_lines {
		em.first_visible_index -= v.max_event_selector_lines / 3
	} else {
		em.first_visible_index = 0
	}

	for i := range em.buttons {
		em.buttons[i].Widget.Hide()
	}

	limit := em.first_visible_index + v.max_event_selector_lines
	if int(limit) > len(em.buttons) {
		limit = uint(len(em.buttons))
	}

	for i := em.first_visible_index; i < limit; i++ {
		em.buttons[i].Widget.Show()
	}
}

func down_button_clicked(w gtk.Widget, o gtk.Opaque) {
	em := &eventsel_main
	v := &g2_main.v
	if int(em.first_visible_index) < len(em.buttons) {
		em.first_visible_index += v.max_event_selector_lines
	}

	for i := range em.buttons {
		em.buttons[i].Widget.Hide()
	}

	limit := em.first_visible_index + v.max_event_selector_lines
	if int(limit) > len(em.buttons) {
		limit = uint(len(em.buttons))
	}

	for i := em.first_visible_index; i < limit; i++ {
		em.buttons[i].Widget.Show()
	}
}

func (v *view) event_selector_init() {
	fc := &g2_main.current_file
	em := &eventsel_main

	// No file? No list of events
	if !fc.Initialized {
		return
	}
	em.vbox = gtk.NewBox(gtk.Vertical, 5 /* spacing */)
	em.hbox = gtk.NewBox(gtk.Horizontal, 5 /* spacing */)

	em.buttons = make([]gtk.ToggleButton, 0)

	// Put check buttons into vbox
	fc.event_definitions.Foreach(func(ed *EventDefinition) {
		// Big fat ugly warning: ed.name contains format specifiers!

		// b := gtk.NewToggleButtonWithLabel("[%d] %s\x00", int(ed.event_id),
		//        ed.name) blows chunks...

		label := std.Format("[%d] %s\x00", int(ed.event_id), ed.name)
		b := gtk.NewToggleButtonWithStringLabel(label)
		em.buttons = append(em.buttons, b)
		em.event_id_by_button[b.Widget] = int(ed.event_id)
		b.SetActive(true)
		b.Connect("toggled", select_toggle, b.Opaque())
		em.vbox.Pack(b.Widget, gtk.BoxPack{})
	})

	// Put into hbox
	all_button := gtk.NewButtonWithLabel("All")
	all_button.Connect("clicked", select_all_events, 0)

	none_button := gtk.NewButtonWithLabel("None")
	none_button.Connect("clicked", select_no_events, 0)

	em.hbox.Pack(all_button.Widget, gtk.BoxPack{})
	em.hbox.Pack(none_button.Widget, gtk.BoxPack{})

	if len(em.buttons) > int(v.max_event_selector_lines) {
		up_button := gtk.NewButtonWithLabel("Up")
		up_button.Connect("clicked", up_button_clicked, 0)

		down_button := gtk.NewButtonWithLabel("Down")
		down_button.Connect("clicked", down_button_clicked, 0)

		em.hbox.Pack(up_button.Widget, gtk.BoxPack{})
		em.hbox.Pack(down_button.Widget, gtk.BoxPack{})
	}

	// put hbox into em.vbox
	em.vbox.Pack(em.hbox.Widget, gtk.BoxPack{})

	// put em.vbox into main_hbox
	v.main_hbox.Pack(em.vbox.Widget, gtk.BoxPack{})
}
