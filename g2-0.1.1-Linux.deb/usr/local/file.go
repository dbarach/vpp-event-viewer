package g2

import (
	"std"
	"ui/gtk"
)

type BoundTrack struct {
	track_index   int
	display_index int
	track_str     string
	pool_index    int
	has_events    bool
}

func (fc *FileContents) GetBoundTrack(i int) *BoundTrack {
	return &fc.bound_tracks.Vec[i]
}

func (fc *FileContents) bound_track_pool_get() (rv *BoundTrack) {
	i := int(fc.bound_tracks.GetIndex())
	rv = fc.GetBoundTrack(i)
	*rv = BoundTrack{}
	rv.track_index = -1
	rv.pool_index = i
	return
}

func (fc *FileContents) bound_track_pool_put(i int) {
	ok := fc.bound_tracks.PutIndex(uint(i))
	if ok == false {
		panic("bound track pool put failed!")
	}
}

// Track sort interface, only works when the pool is dense from 0
type tracksort std.Pool[BoundTrack]

func (a *tracksort) Len() int { return int(a.Vec.Len() - a.FreeLen()) }
func (a *tracksort) Less(i, j int) bool {
	return a.Vec[i].track_index < a.Vec[j].track_index
}
func (a *tracksort) Swap(i, j int) {
	a.Vec[i], a.Vec[j] = a.Vec[j], a.Vec[i]
}

const (
	DETAIL_BOX_RENDER_DEFAULT = 0
)

type EventDefinition struct {
	event_id                int
	name                    string
	is_displayed            bool
	pool_index              int
	detail_box_render_style int
}

func (fc *FileContents) GetEventDefinition(i int) *EventDefinition {
	return &fc.event_definitions.Vec[i]
}

func (fc *FileContents) event_definitions_pool_get() (rv *EventDefinition) {
	i := int(fc.event_definitions.GetIndex())
	rv = fc.GetEventDefinition(i)
	*rv = EventDefinition{}
	rv.pool_index = i
	return
}

func (fc *FileContents) event_definitions_pool_put(i int) {
	ok := fc.event_definitions.PutIndex(uint(i))
	if ok == false {
		panic("event definition pool put failed!")
	}
}

// Event def'n sort interface, only works when the pool is dense from 0

type evsort std.Pool[EventDefinition]

func (a *evsort) Len() int { return int(a.Vec.Len() - a.FreeLen()) }
func (a *evsort) Less(i, j int) bool {
	return a.Vec[i].event_id < a.Vec[j].event_id
}

func (a *evsort) Swap(i, j int) {
	a.Vec[i], a.Vec[j] = a.Vec[j], a.Vec[i]
}

const (
	EVENT_FLAG_SELECT        = 1
	EVENT_FLAG_SEARCH_RESULT = 2
)

type Event struct {
	time            uint64
	code            uint32
	pad             uint32
	raw_event_index uint32
	flags           uint32
	track_index     int
	pool_index      int
}

func (fc *FileContents) GetEvent(i int) *Event {
	return &fc.events.Vec[i]
}

func (fc *FileContents) events_pool_get() (rv *Event) {
	i := int(fc.events.GetIndex())
	rv = fc.GetEvent(i)
	*rv = Event{}
	rv.pool_index = i
	return
}

func (fc *FileContents) events_pool_put(i int) {
	ok := fc.events.PutIndex(uint(i))
	if ok == false {
		panic("event definition pool put failed!")
	}
}

type FileContents struct {
	events            std.Pool[Event]
	bound_tracks      std.Pool[BoundTrack]
	event_definitions std.Pool[EventDefinition]
	track_display_map map[int]int
	WidestTrackString int
	file_name         string
	Initialized       bool
}

func (fc *FileContents) find_or_add_track(track_index, event_index int) int {

	// Known track_index, return the bound track pool index, mark track used
	if rv, ok := fc.track_display_map[track_index]; ok {
		bt := fc.GetBoundTrack(track_index)
		bt.has_events = true
		return rv
	}

	// Synthesize a track. "Should never happen...".
	bt := fc.bound_track_pool_get()
	bt.track_index = track_index
	bt.display_index = track_index
	bt.has_events = true
	tmp := std.Format("Unknown %d", track_index)
	bt.track_str = save(tmp)
	if len(bt.track_str) > fc.WidestTrackString {
		fc.WidestTrackString = len(bt.track_str)
	}

	fc.track_display_map[track_index] = bt.display_index
	return bt.pool_index
}

type ElogFile interface {
	ElogFileValid() bool
	ElogFileSupported(s string) bool
	ElogFileRenderSelectedEvent(event_index int) (rectangle, string)
	ElogFilePaintSelectedEvent(*selected_event, gtk.CairoContext)
	ElogReadFile(string) int
	ElogFileIsLiveLog() bool
	ElogGetAnomalyData(int, uint32) (valid bool, track int, value float64)
	ElogQuit(w gtk.Widget, o gtk.Opaque)
}
