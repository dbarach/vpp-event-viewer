//go:build vpp

package g2

// #include <vppinfra/elog.h>
// #include "g2.h"
import "C"

import (
	"net/vpp"
	"sort"
	"std"
	"ui/gtk"
	"unsafe"
)

type vpp_elog_main_t struct {
	valid     bool
	elog_main *C.elog_main_t
}

var vpp_elog_main vpp_elog_main_t

func my_activate(app gtk.Application, _ gtk.Opaque) {
	g2_main.app = app
	open_elog_file("[vpp live log]")
	g2_main.view_init(app)
}

// Called from c-code on the vpp viewer pthread
func Vpp_start_g2() {
	g2_file_types = []ElogFile{vpp_elog_main}

	emp := C.vlib_get_elog_main_not_inline()
	vpp_elog_main.elog_main = emp

	// So that g2_main.ef.ElogFileValid() will say "no" if
	// no file provided on the command line...
	g2_main.ef = g2_file_types[0]

	args := []string{"g2"}
	app := gtk.NewApplication("fd.io.g2", gtk.GApplicationFlagsNone)
	app.Connect("activate", my_activate)
	rv := app.Run(args)
	if rv < 0 {
		std.Logf("Graphics initialization failed, check $DISPLAY...\n\n")
	}
}

func get_vpp_elog_event_time(e *C.elog_event_t) float64 {
	return *(*float64)(unsafe.Pointer(e))
}

func vec_len_not_inline(p unsafe.Pointer) (rv uint) {
	p = unsafe.Pointer(uintptr(p) - 8 /* sizeof(vec_header_t) */)
	rv = uint(*(*uint32)(p))
	return
}

func (vem vpp_elog_main_t) ElogReadFile(clib_file string) int {
	fc := &g2_main.current_file
	vemp := &vpp_elog_main
	em := vpp_elog_main.elog_main

	C.elog_get_events(em)

	fc.WidestTrackString = -1

	// Throw away previous data, if any
	if vemp.valid {
		// $$$ Needs leak-finder brain police
		fc.events.Reset()

		fc.bound_tracks.Foreach(func(bt *BoundTrack) {
			free(bt.track_str)
		})
		fc.bound_tracks.Reset()
		fc.event_definitions.Reset()
		for k := range fc.track_display_map {
			delete(fc.track_display_map, k)
		}
	}

	// Build track database
	tracks := []C.elog_track_t(em.tracks, vec_len_not_inline(unsafe.Pointer(em.tracks)))
	for i := range tracks {
		tp := &tracks[i]

		bt := fc.bound_track_pool_get()
		// Events contain track_id + 1
		bt.track_index = i
		bt.display_index = i
		if _, ok := fc.track_display_map[i]; ok {
			std.Logf("Track code %d redefined, keep first definition...\n", i)
			fc.bound_track_pool_put(i)
			continue
		}

		bt.track_str = save(string(tp.name, vec_len_not_inline(unsafe.Pointer(tp.name))))
		if len(bt.track_str) > fc.WidestTrackString {
			fc.WidestTrackString = len(bt.track_str)
		}
		fc.track_display_map[bt.track_index] = bt.display_index
	}

	// Build event database
	event_types := []C.elog_event_type_t(em.event_types, vec_len_not_inline(unsafe.Pointer(em.event_types)))
	for i := range event_types {
		e := &event_types[i]

		event := fc.event_definitions_pool_get()
		if int(e.type_index_plus_one) <= 0 {
			panic("raw event index zero or worse")
		}
		event.event_id = int(e.type_index_plus_one) - 1
		event.is_displayed = true
		event.name = save(string(e.format, vec_len_not_inline(unsafe.Pointer(e.format))))
	}

	// Based on one event log, it seems like
	// the events show up sorted, but since the old viewer sorts
	// the definitions I have the feeling we'd better do it.
	sort.Sort((*evsort)(&fc.event_definitions))

	// Build events
	events := []C.elog_event_t(em.events, vec_len_not_inline(unsafe.Pointer(em.events)))
	starttime := get_vpp_elog_event_time(&events[0]) * 1e9

	for i := range events {
		e := &events[i]
		event_time := get_vpp_elog_event_time(e)
		event := fc.events_pool_get()
		event.time = uint64(event_time*1e9 - starttime)
		event.code = uint32(e.event_type)
		event.track_index = fc.find_or_add_track(int(e.track), i)
		event.raw_event_index = uint32(i)
	}

	// Sort tracks, rebuild map
	sort.Sort((*tracksort)(&fc.bound_tracks))
	for k := range fc.track_display_map {
		delete(fc.track_display_map, k)
	}

	for k := 0; k < int(fc.bound_tracks.Elts()); k++ {
		track := fc.GetBoundTrack(k)
		track.pool_index = k
		track.display_index = k
		fc.track_display_map[track.track_index] = track.display_index
	}
	fc.file_name = save(clib_file)
	fc.Initialized = true
	vemp.valid = true

	return 0
}

func (em vpp_elog_main_t) ElogFileSupported(fn string) bool {
	if fn != "[vpp live log]" {
		return false
	}
	return true
}

func (em vpp_elog_main_t) ElogFileIsLiveLog() bool { return true }

func get_elog_event_t(p unsafe.Pointer) *C.elog_event_t {
	return (*C.elog_event_t)(p)
}

func (em vpp_elog_main_t) ElogGetAnomalyData(i int, event_code uint32) (valid bool, track int, value float64) {
	emp := vpp_elog_main.elog_main
	event := g2_main.current_file.GetEvent(i)

	raw_events := unsafe.Pointer(emp.events)
	ep := unsafe.Pointer(uintptr(raw_events) + uintptr(event.pool_index)*
		unsafe.Sizeof(C.elog_event_t{}))

	raw_event := get_elog_event_t(ep)

	if uint32(raw_event.event_type) != event_code {
		valid = false
		return
	}

	p := unsafe.Pointer(&raw_event.data)
	vp := (*C.u32)(p)

	valid = true
	track = int(raw_event.track)
	value = float64(uint32(*vp))

	return
}

func (em vpp_elog_main_t) ElogFileValid() bool {
	return vpp_elog_main.valid
}

func vpp_event_format(i int) (s string) {
	em := vpp_elog_main.elog_main
	event := g2_main.current_file.GetEvent(i)

	events := []C.elog_event_t(em.events, vec_len_not_inline(unsafe.Pointer(em.events)))
	ep := &events[event.pool_index]

	if (event.flags & EVENT_FLAG_SELECT) != 0 {
		rv := C.format_one_elog_event(unsafe.Pointer(em), unsafe.Pointer(ep))
		s = save(string(rv, C.vec_len_not_inline(unsafe.Pointer(rv))))
		C.vec_free_not_inline(unsafe.Pointer(rv))
	} else {
		// Search result - save it, so we can free it...
		s = save("SearchResult")
	}

	return
}

func (vem vpp_elog_main_t) ElogFileRenderSelectedEvent(event_index int) (r rectangle, s string) {
	s = vpp_event_format(event_index)
	r = rectangle{}
	strs := newline_string_slice(s)
	r.init_for_string(gtk.X{}, strs)
	free(strs)
	return
}

func (vem vpp_elog_main_t) ElogFilePaintSelectedEvent(se *selected_event, c gtk.CairoContext) {
	v := &g2_main.v
	v.flag_box(se.event, c, se.where, se.end, se.contents)
}

func (vem vpp_elog_main_t) ElogQuit(w gtk.Widget, o gtk.Opaque) {
}

// +ego { section(.vlib_plugin_r2) }
var plugin_reg = vpp.PluginRegistration{
	Description: "G2 Live Viewer plugin",
	Version:     "v0.1",
}
