//go:build !ggo

package g2

import "math"

func (v *view) compute_anomaly_stats() {
	fc := &g2_main.current_file

	if !v.g.search_code_set {
		message_box("Error", "Search code not set")
		return
	}

	//
	if !g2_main.ef.ElogFileValid() {
		return
	}

	nevents := int(fc.events.Elts())
	if nevents == 0 {
		message_box("Error", "No events??")
		return
	}

	ntracks := int(fc.bound_tracks.Elts())
	if nevents == 0 {
		message_box("Error", "No tracks??")
		return
	}

	if v.anomaly_threshold_by_track_set {
		free(v.anomaly_threshold_by_track)
	}

	means := make([]float64, ntracks)
	variances := make([]float64, ntracks)
	events_per_track := make([]float64, ntracks)
	thresholds := make([]float64, ntracks)

	// Per-track sum of event data, for the given event type
	for i := 0; i < nevents; i++ {
		valid, track, value := g2_main.ef.ElogGetAnomalyData(i, v.g.search_code)
		if !valid {
			continue
		}
		means[track] += value
		events_per_track[track]++
	}
	// Compute means
	for i := 0; i < ntracks; i++ {
		if events_per_track[i] != 0 {
			means[i] /= events_per_track[i]
		}
	}
	// Compute sum  (Xi-Xbar)**2
	for i := 0; i < nevents; i++ {
		valid, track, value := g2_main.ef.ElogGetAnomalyData(i, v.g.search_code)
		if !valid {
			continue
		}
		variances[track] += (value - means[track]) * (value - means[track])
	}

	// Normalize, divide by number of events
	for i := 0; i < ntracks; i++ {
		if events_per_track[i] != 0 {
			variances[i] /= events_per_track[i]
		}
	}

	// Compute the anomaly thresholds
	for i := 0; i < ntracks; i++ {
		if events_per_track[i] != 0 {
			thresholds[i] = means[i] + v.anomaly_threshold_stddevs*
				math.Sqrt(variances[i])
		}
	}
	v.anomaly_threshold_by_track = save(thresholds)
	v.anomaly_threshold_by_track_set = true
}
