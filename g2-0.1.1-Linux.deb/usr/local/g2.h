#include <vnet/vnet.h>

void ego_start_thread (vlib_cli_command_function_t *f);
int ego_gtk_start_check (void);
