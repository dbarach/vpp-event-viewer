package g2

import (
	"std"
	"sys"
	"ui/gtk"
)

const debug_flag = true

func debug(fmt string, args ...interface{}) {
	if debug_flag {
		std.Logf(fmt, args)
	}
}

type g2_main_t struct {
	v            view
	app          gtk.Application
	ef           ElogFile
	current_file FileContents
}

var g2_main g2_main_t

func g2_activate(app gtk.Application, _ gtk.Opaque) {
	g2_main.app = app
	g2_main.view_init(app)
}

var g2_file_types []ElogFile

func open_elog_file(filename string) bool {
	found_file := false

	for i := range g2_file_types {
		ef := g2_file_types[i]
		if ef.ElogFileSupported(filename) {
			g2_main.ef = ef
			found_file = true
			break
		}
	}
	if found_file {
		g2_main.ef.ElogReadFile(filename)
		return true
	}
	return false
}

const version = "unknown"

func show_version() {
	std.Logf("%s\n", version)
	sys.ExitGroup(0)
}

func main() {
	g2_file_types = save([]ElogFile{elog_elog_main})

	// So that g2_main.ef.ElogFileValid() will say "no" if
	// no file provided on the command line...
	g2_main.ef = g2_file_types[0]

	var filename string
	for in := std.CommandLineInput; !in.End(); {
		switch {
		case in.Parse("file %v", &filename):
			filename += "\x00"
			if !open_elog_file(filename) {
				std.Fatalf("Couldn't open '%s'\n", filename)
			}
			break
		case in.Parse("version"):
			show_version()
		default:
			std.Fatalf("unknown input '%s'\n", in.Error())
		}
	}

	// The gtk arg parser is a nightmare, so don't use it.
	args := []string{std.CommandLineArgs[0]}
	app := gtk.NewApplication("fd.io.g2", gtk.GApplicationFlagsNone)
	app.Connect("activate", g2_activate)
	sys.ExitGroup(app.Run(args))
}
