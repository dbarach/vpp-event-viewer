//go:build !ggo
// +build !ggo

package g2

import (
	"ui/gtk"
	"unsafe"
)

type dialogfunc func(string)

func get_dialog_pointer(o gtk.Opaque) *func(string) {
	return (*func(string))(unsafe.Pointer(uintptr(o)))
}

var current_modal_dialog gtk.Dialog
var current_entry gtk.Entry

func do_dialog(w gtk.Widget, o gtk.Opaque) {
	var f *func(string)

	if o != gtk.Opaque(0) {
		f = get_dialog_pointer(o)
		s := current_entry.GetText()
		(*f)(s)
	}
	current_modal_dialog.Destroy()
}

func modal_dialog(title, label_text, dflt string, f dialogfunc) {
	d := gtk.NewDialogWithButtons(title, g2_main.v.w, 0)
	current_modal_dialog = d

	label := gtk.NewLabel(label_text)

	ok_button := gtk.NewButtonWithLabel("OK")
	ok_button.Connect("clicked", do_dialog,
		gtk.Opaque(uintptr(unsafe.Pointer(&f))))
	cancel_button := gtk.NewButtonWithLabel("Cancel")
	cancel_button.Connect("clicked", do_dialog, gtk.Opaque(uintptr(0)))

	entry := gtk.NewEntry()
	current_entry = entry
	entry.SetText(dflt)

	hbox := gtk.NewBox(gtk.Horizontal, 5)
	hbox.Pack(ok_button.Widget, gtk.BoxPack{})
	hbox.Pack(cancel_button.Widget, gtk.BoxPack{})

	vbox := gtk.NewBox(gtk.Vertical, 5)
	vbox.Pack(label.Widget, gtk.BoxPack{})
	vbox.Pack(entry.Widget, gtk.BoxPack{Expand: true, Fill: true})
	vbox.Pack(hbox.Widget, gtk.BoxPack{})

	da := d.GetContentArea()
	da.Add(vbox.Widget)

	entry.Widget.GrabFocus()
	d.ShowAll()
	d.Run()
}

func clear_message_box(w gtk.Widget, o gtk.Opaque) {
	current_modal_dialog.Destroy()
}

func message_box(title, s string) {
	label := gtk.NewLabel(s)
	d := gtk.NewDialogWithButtons(title, g2_main.v.w, 0)
	current_modal_dialog = d

	ok_button := gtk.NewButtonWithLabel("OK")
	ok_button.Connect("clicked", clear_message_box, gtk.Opaque(0))
	hbox := gtk.NewBox(gtk.Horizontal, 5)
	hbox.Pack(ok_button.Widget, gtk.BoxPack{Expand: true})

	vbox := gtk.NewBox(gtk.Vertical, 5)
	vbox.Pack(label.Widget, gtk.BoxPack{Expand: true})
	vbox.Pack(hbox.Widget, gtk.BoxPack{Expand: true})

	da := d.GetContentArea()
	da.Add(vbox.Widget)

	ok_button.CanDefault(true)
	ok_button.GrabDefault()
	d.Widget.GrabFocus()
	d.ShowAll()
	d.Run()
}

type radio_state struct {
	value  int
	dialog gtk.Dialog
}

var rs radio_state

func radio_cancel(w gtk.Widget, o gtk.Opaque) {
	rs.value = -1
	rs.dialog.Destroy()
}

func radio_ok(w gtk.Widget, o gtk.Opaque) {
	rs.dialog.Destroy()
}

func radio_toggle(w gtk.Widget, o gtk.Opaque) {
	is_active := w.GetActive()

	// expect to get two hits when the user toggle the radio selectoin
	if is_active {
		rs.value = int(o)
		return
	}
	if rs.value == int(o) {
		rs.value = -1
	}
}

func radio_dialog(title string, buttons []string) int {
	d := gtk.NewDialogWithButtons(title, g2_main.v.w, 0)
	rs.dialog = d
	rs.value = -1

	ok_button := gtk.NewButtonWithLabel("OK")
	ok_button.Connect("clicked", radio_ok, gtk.Opaque(0))
	cancel_button := gtk.NewButtonWithLabel("Cancel")
	cancel_button.Connect("clicked", radio_cancel, gtk.Opaque(0))

	hbox := gtk.NewBox(gtk.Horizontal, 5)

	hbox.Pack(ok_button.Widget, gtk.BoxPack{})
	hbox.Pack(cancel_button.Widget, gtk.BoxPack{})

	vbox := gtk.NewBox(gtk.Vertical, 5)

	var b, group_leader gtk.RadioButton
	for i := range buttons {
		if i == 0 {
			b = gtk.NewRadioButtonGroup(buttons[i])
			group_leader = b
			b.SetActive(true)
			rs.value = 0
		} else {
			b = gtk.AddRadioButtonToGroup(group_leader, buttons[i])
			b.SetActive(false)
		}
		b.Connect("toggled", radio_toggle, gtk.Opaque(i))
		vbox.Pack(b.Widget, gtk.BoxPack{})
	}

	vbox.Pack(hbox.Widget, gtk.BoxPack{})

	da := d.GetContentArea()
	da.Add(vbox.Widget)

	ok_button.CanDefault(true)
	ok_button.GrabDefault()
	d.Widget.GrabFocus()
	d.ShowAll()
	d.Run()
	return rs.value
}

/*
gtk_window_set_focus(GTK_WINDOW(dialog), NULL);
gtk_widget_set_can_default(ok_button,TRUE);
gtk_window_set_default(GTK_WINDOW(dialog), ok_button);
*/
