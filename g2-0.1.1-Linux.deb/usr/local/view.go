package g2

import (
	"runtime"
	"std"
	"ui/gtk"
)

// button IDs
const (
	ANOMALY_BUTTON = iota
	ANOMALY_NEXT_BUTTON
	ANOMALY_THRESHOLD_BUTTON
	BACKWARD_BUTTON
	BOTTOM_BUTTON
	CHASE_DATUM_BUTTON
	CHASE_EVENT_BUTTON
	CHASE_TRACK_BUTTON
	DEL_BUTTON
	END_BUTTON
	FILE_BUTTON
	FORWARD_BUTTON
	LESS_TRACES_BUTTON
	MORE_TRACES_BUTTON
	NEXT_BUTTON
	NO_CHASE_BUTTON
	NO_CHASE_TRACK_BUTTON
	NO_SUMMARY_BUTTON
	SEARCH_AGAIN_BUTTON
	SEARCH_BUTTON
	SLEW_LEFT_BUTTON
	SLEW_RIGHT_BUTTON
	SNAP_BUTTON
	START_BUTTON
	SUMMARY_BUTTON
	TOP_BUTTON
	VPP_LIVE_BUTTON
	ZOOMIN_BUTTON
	ZOOMOUT_BUTTON
)

// Strings must match constants, or confusion will ensue...
const (
	TRACK_MOVE_FIRST_VISIBLE = iota
	TRACK_MOVE_LAST_VISIBLE
	TRACK_MOVE_TOP
	TRACK_MOVE_BOTTOM
)

var track_move_buttons = []string{"First Visible", "Last Visible", "First",
	"Last"}

// Mouse gesture handling, main drawing area only
type mouse_state struct {
	which_button     gtk.EventButtonId
	start_location   gtk.X
	current_location gtk.X
	active           bool
}

type keyboard_state struct {
	control_key_down bool
	shift_key_down   bool
}

type snappable_geometry struct {
	// Captured in snapshots
	draw_width         uint
	draw_height        uint
	track_ax_width     uint
	time_ax_height     uint
	time_ax_spacing    uint
	strip_height       uint
	pop_offset         uint
	event_offset       uint
	first_track_index  uint
	ntracks            uint
	minvistime         uint
	maxvistime         uint
	summary_mode       bool
	search_code        uint32
	search_code_set    bool
	search_index       uint
	search_index_valid bool
	search_forward     bool
}

type snapshot struct {
	g                      snappable_geometry
	displayed_event_types  std.Bitmap
	selected_event_indices []int
	track_display_map      []int
}

type view struct {
	g                              snappable_geometry
	snapshots                      []snapshot
	current_snapshot_index         int
	max_event_selector_lines       uint
	memory_trace_enable            bool
	anomaly_threshold_stddevs      float64
	anomaly_threshold_by_track     []float64
	anomaly_threshold_by_track_set bool
	main_hbox                      gtk.Box
	event_selector                 gtk.Box
	zoom_cursor                    gtk.Cursor
	time_ruler_cursor              gtk.Cursor
	grabbing_cursor                gtk.Cursor
	move_cursor                    gtk.Cursor
	default_cursor                 gtk.Cursor
	hscroll_adjustment             gtk.Adjustment
	vscroll_adjustment             gtk.Adjustment
	forward_button                 gtk.Button
	backward_button                gtk.Button
	summary_button                 gtk.Button
	no_summary_button              gtk.Button
	ms                             mouse_state
	ks                             keyboard_state
	w                              gtk.Window
	da                             gtk.DrawingArea
	current_surface                gtk.CairoSurface
	current_surface_set            bool
	current_surface_size           gtk.X
}

func (v *view) make_snapshot() {
	if !g2_main.ef.ElogFileValid() {
		message_box("NoFile", "No file loaded")
		return
	}

	fc := &g2_main.current_file
	s := snapshot{g: v.g}
	s.selected_event_indices = save(make([]int, 0))

	// Save bitmap of displayed event types
	fc.event_definitions.Foreach(func(ed *EventDefinition) {
		if ed.is_displayed {
			s.displayed_event_types.Set(uint(ed.event_id))
		}
	})
	// Save indices of selected events.
	for i := 0; i < int(fc.events.Elts()); i++ {
		e := fc.GetEvent(i)
		if e.flags&EVENT_FLAG_SELECT != 0 {
			s.selected_event_indices = append(s.selected_event_indices, int(i))
		}
	}
	// Save track display map
	s.track_display_map = make([]int, int(fc.bound_tracks.Elts())-1)
	for i := uint(0); i < fc.bound_tracks.Elts(); i++ {
		this_track := fc.GetBoundTrack(int(i))
		s.track_display_map[i] = this_track.display_index
	}

	// And create a snapshot
	v.snapshots = append(v.snapshots, s)
	v.current_snapshot_index = len(v.snapshots) - 1
}

func (v *view) next_snapshot() {
	if v.current_snapshot_index == -1 {
		message_box("NoSnaps", "There are no snapshots in the ring")
		return
	}

	fc := &g2_main.current_file

	v.current_snapshot_index++
	if v.current_snapshot_index >= len(v.snapshots) {
		v.current_snapshot_index = 0
	}

	s := v.snapshots[v.current_snapshot_index]
	// Restore view geometry
	v.g = s.g

	// Restore event selector
	fc.event_definitions.Foreach(func(ed *EventDefinition) {
		ed.is_displayed = false
	})
	s.displayed_event_types.ForeachSetBit(func(bit uint) {
		fc.event_definitions.Vec[bit].is_displayed = true
	})

	// Clear currently-selected event flags
	for i := 0; i < int(fc.events.Elts()); i++ {
		e := fc.GetEvent(i)
		e.flags &^= EVENT_FLAG_SELECT
	}
	// Restore selected events
	for i := range s.selected_event_indices {
		e := fc.GetEvent(s.selected_event_indices[i])
		e.flags |= EVENT_FLAG_SELECT
	}
	// Restore track display map
	for i := uint(0); i < fc.bound_tracks.Elts(); i++ {
		this_track := fc.GetBoundTrack(int(i))
		this_track.display_index = s.track_display_map[i]
		fc.track_display_map[this_track.track_index] = this_track.display_index
	}

	v.recompute_hscroll()
	v.recompute_vscroll()
	v.repaint()
}

func (v *view) delete_snapshot() {
	if v.current_snapshot_index == -1 {
		message_box("NoSnaps", "There are no snapshots in the ring")
		return
	}

	s := v.snapshots[v.current_snapshot_index]
	s.displayed_event_types.Free()
	free(s.selected_event_indices)
	free(s.track_display_map)
	v.snapshots = append(v.snapshots[:v.current_snapshot_index],
		v.snapshots[v.current_snapshot_index+1:]...)

	if v.current_snapshot_index >= len(v.snapshots) {
		v.current_snapshot_index = 0
	}
	if v.current_snapshot_index >= len(v.snapshots) {
		v.current_snapshot_index = -1
	}
}

func (v *view) repaint() {
	v.da.Widget.QueueDraw()
}

func configure_event(w gtk.Widget, o gtk.Opaque) {
	v := &g2_main.v

	size := w.Size()
	draw_size := size * gtk.X{0.8, 0.8}
	// This appears to be a suggestion
	v.da.SetSize(draw_size)
	// Figure out what we actually got
	v.g.draw_width = v.da.Widget.Width()
	v.g.draw_height = v.da.Widget.Height()

	//	std.Logf("new width %d height %d\n",
	//		v.g.draw_width, v.g.draw_height)

	v.g.ntracks = (v.g.draw_height - v.g.time_ax_height) / v.g.strip_height

	if g2_main.ef.ElogFileValid() {
		v.recompute_hscroll()
		v.recompute_vscroll()
	}
	v.repaint()
}

// Mouse button down: note location,
func button_press_event(w gtk.Widget, o gtk.Opaque) {
	v := &g2_main.v
	ms := &v.ms
	ks := &v.ks
	e := o.EventButton()
	ms.which_button = e.GetButtonId()
	ms.start_location = e.GetX()

	ms.active = true
	// Zoom button
	if ms.which_button == 1 /* left mouse */ {
		if ks.shift_key_down {
			v.w.Widget().SetCursor(v.move_cursor)
		} else if ks.control_key_down {
			v.w.Widget().SetCursor(v.grabbing_cursor)
		} else {
			v.w.Widget().SetCursor(v.zoom_cursor)
		}
	} else if ms.which_button == 3 /* right mouse */ {
		v.w.Widget().SetCursor(v.time_ruler_cursor)
	}
}

func (v *view) mouse_zoom_event(X gtk.X) {

	startx := v.ms.start_location[0]
	endx := X[0]

	if startx < float64(v.g.track_ax_width) {
		startx = float64(v.g.track_ax_width)
	}
	if endx < float64(v.g.track_ax_width) {
		endx = float64(v.g.track_ax_width)
	}

	delta_x := endx - startx
	if delta_x < 0.0 {
		delta_x = -delta_x
	}

	// Width in pixels of half the zoom area
	width_in_pixels := delta_x / 2.0
	time_per_pixel := v.time_per_pixel()
	width_in_time := width_in_pixels * time_per_pixel

	center_on_pixel := (startx+endx)/2.0 - float64(v.g.track_ax_width)
	center_on_time := float64(v.g.minvistime) + center_on_pixel*time_per_pixel

	if center_on_time-width_in_time < 0.0 {
		panic("minvistime less than zero!")
	}
	v.g.minvistime = uint(center_on_time - width_in_time)
	v.g.maxvistime = uint(center_on_time + width_in_time)
	v.recompute_hscroll()
	v.repaint()
}

// rectangle canonical form, "computer graphics" coordinate space
// it's simpler to store all of the vertices...
type rectangle struct {
	upper_left, lower_left   gtk.X
	upper_right, lower_right gtk.X
}

func (r *rectangle) translate(x gtk.X) {
	r.upper_left += x
	r.lower_left += x
	r.upper_right += x
	r.lower_right += x
}
func (r *rectangle) expand(dx gtk.X) {
	r.upper_left += gtk.X{-dx[0], -dx[1]}
	r.lower_left += gtk.X{-dx[0], dx[1]}
	r.upper_right += gtk.X{dx[0], -dx[1]}
	r.lower_right += gtk.X{dx[0], dx[1]}
}

// This is a hack. Should be no need to tell Cairo to do this N times
func set_font_and_line_width(c gtk.CairoContext) {
	c.SetFont("Mono", gtk.FontSlantNormal, gtk.FontWeightNormal)
	c.SetFontSize(18)
	c.SetSourceColor(gtk.Black)
	c.SetLineWidth(1.0)
}

func newline_string_slice(s string) []string {
	var i int
	var one_line string
	strs := makes([]string, 0)
	b := []byte(s)
	start_index := 0
	for i = 0; i < len(b); i++ {
		if b[i] == '\n' {
			one_line = s[start_index:i]
			strs = appends(strs, one_line)
			start_index = i + 1
		}
	}
	if start_index < len(b) {
		one_line = s[start_index:len(b)]
		strs = appends(strs, one_line)
	}

	return save(strs)
}

// Make the rectangle for a boxed set of string
func (r *rectangle) init_for_string(X gtk.X, strs []string) {
	c := g2_main.v.current_surface.Context()
	set_font_and_line_width(c)

	// Figure out the max delta_x and total delta_y
	max_delta_x := float64(0)
	total_delta_y := float64(0)

	fe := c.FontExtents()

	for i := range strs {
		te := c.TextExtents(strs[i])
		delta_x := (te.Advance[0])
		if delta_x > max_delta_x {
			max_delta_x = delta_x
		}
		total_delta_y += fe.Height
	}

	x_center_point := max_delta_x / 2.0

	// Note: the underlying Cairo library routines return a very tight
	// horizontally assymetric box, so tweak the dimensions here

	r.upper_left = X + gtk.X{-x_center_point, 0}
	r.lower_left = X + gtk.X{-x_center_point, total_delta_y}
	r.lower_right = X + gtk.X{x_center_point, total_delta_y}
	r.upper_right = X + gtk.X{x_center_point, 0}
	// Add margins: 5% of height; 1/2 of a max-sized glyph width.
	r.expand(gtk.X{.5 * fe.MaxAdvance[0], .05 * fe.Height})
}

func (r *rectangle) contains(X gtk.X) bool {
	if X[0] < r.upper_left[0] || X[0] > r.upper_right[0] {
		return false
	}
	if X[1] < r.upper_left[1] || X[1] > r.lower_right[1] {
		return false
	}
	return true
}

func (r1 rectangle) intersects(r2 rectangle) bool {
	if r1.contains(r2.upper_left) {
		return true
	}
	if r1.contains(r2.upper_right) {
		return true
	}
	if r1.contains(r2.lower_left) {
		return true
	}
	if r1.contains(r2.lower_right) {
		return true
	}
	return false
}

func (v *view) toggle_event_select(X gtk.X) {
	repaint := walk_event_data(v, gtk.Widget{}, gtk.CairoContext{}, X, true)
	if repaint {
		v.repaint()
	}
}

func (v *view) best_match_track_display_index(X gtk.X) int {
	best_match_track_display_index := int(-1)
	best_match_abs_delta := 1e70

	mouse_y := X[1]

	for i := 0; i < int(v.g.ntracks); i++ {
		y := float64(uint(i)*v.g.strip_height + v.g.event_offset)
		abs_dy := y - mouse_y
		if abs_dy < 0 {
			abs_dy = -abs_dy
		}
		if abs_dy < best_match_abs_delta {
			best_match_track_display_index = i
			best_match_abs_delta = abs_dy
		}
	}
	return best_match_track_display_index
}

func (v *view) track_move_to_index(t *BoundTrack, new_display_index int) {
	fc := &g2_main.current_file

	// No-op?
	if t.display_index == new_display_index {
		return
	}

	old_display_index := t.display_index
	move_up := new_display_index < old_display_index

	for i := 0; i < int(fc.bound_tracks.Elts()); i++ {
		track := fc.GetBoundTrack(i)
		this_display_index := track.display_index
		if this_display_index == old_display_index {
			track.display_index = new_display_index
			fc.track_display_map[track.track_index] = new_display_index
			continue
		}
		if (move_up && (this_display_index >= new_display_index)) ||
			(this_display_index > new_display_index) {
			track.display_index++
			fc.track_display_map[track.track_index] = track.display_index
		}
		if (move_up && (this_display_index > old_display_index)) ||
			(this_display_index >= old_display_index) {
			track.display_index--
			fc.track_display_map[track.track_index] = track.display_index
		}
	}
}
func (v *view) reset_key_state() {
	ks := &v.ks
	ks.shift_key_down = false
	ks.control_key_down = false
}

func (v *view) move_track(X gtk.X) {
	var track_to_move *BoundTrack
	fc := &g2_main.current_file

	best_match_track_display_index := v.best_match_track_display_index(X)

	if best_match_track_display_index == -1 {
		return
	}

	track_display_index_to_move := best_match_track_display_index +
		int(v.g.first_track_index)

	found := false
	for i := uint(0); i < fc.bound_tracks.Elts(); i++ {
		track_to_move = fc.GetBoundTrack(int(i))
		if track_to_move.display_index == track_display_index_to_move {
			found = true
			break
		}
	}
	if !found {
		std.Logf("Oops, couldn't find display index to raise: %d\n",
			track_display_index_to_move)
		return
	}

	title := std.Format("Move %s", track_to_move.track_str)
	track_move_choice := radio_dialog(title, track_move_buttons)
	free(title)

	// Fun fact: the radio dialog eats (shift,control) key release events
	v.reset_key_state()

	if track_move_choice == int(-1) {
		return
	}

	new_display_index := int(-1)

	switch track_move_choice {
	case TRACK_MOVE_FIRST_VISIBLE:
		new_display_index = int(v.g.first_track_index)
	case TRACK_MOVE_LAST_VISIBLE:
		new_display_index = int(fc.bound_tracks.Elts()) - 1
		if new_display_index >= int(v.g.first_track_index+v.g.ntracks) {
			new_display_index = int(v.g.first_track_index+v.g.ntracks) - 1
		}
	case TRACK_MOVE_TOP:
		new_display_index = 0
	case TRACK_MOVE_BOTTOM:
		new_display_index = int(fc.bound_tracks.Elts()) - 1
	}
	v.track_move_to_index(track_to_move, new_display_index)
}

func (v *view) raise_track(X gtk.X) {
	var track_to_raise, track_to_lower *BoundTrack
	fc := &g2_main.current_file
	best_match_track_display_index := v.best_match_track_display_index(X)

	if best_match_track_display_index == -1 {
		return
	}

	track_display_index_to_raise := best_match_track_display_index +
		int(v.g.first_track_index)

	found := false
	for i := uint(0); i < fc.bound_tracks.Elts(); i++ {
		track_to_raise = fc.GetBoundTrack(int(i))
		if track_to_raise.display_index == track_display_index_to_raise {
			found = true
			break
		}
	}
	if !found {
		std.Logf("Oops, couldn't find display index to raise: %d\n",
			track_display_index_to_raise)
		return
	}

	// Already the top track? Fagedaboudit...
	if track_to_raise.display_index == 0 {
		return
	}

	// Find track with display index n - 1
	found = false
	for i := uint(0); i < fc.bound_tracks.Elts(); i++ {
		track_to_lower = fc.GetBoundTrack(int(i))
		if track_to_lower.display_index == track_display_index_to_raise-1 {
			found = true
			break
		}
	}
	if !found {
		std.Logf("Oops, couldn't find display index to lower: %d\n",
			track_display_index_to_raise)
		return
	}

	// Swap display tracks
	track_to_raise.display_index, track_to_lower.display_index =
		track_to_lower.display_index, track_to_raise.display_index

	fc.track_display_map[track_to_raise.track_index] =
		track_to_raise.display_index
	fc.track_display_map[track_to_lower.track_index] =
		track_to_lower.display_index

}

func button_release_event(w gtk.Widget, o gtk.Opaque) {
	v := &g2_main.v
	ms := &v.ms
	ks := &v.ks
	e := o.EventButton()
	X := e.GetX()
	button := e.GetButtonId()

	if button != ms.which_button {
		std.Logf("Button %d supposedly pressed, but button %d released",
			ms.which_button, button)
		ms.active = false
		return
	}

	delta := ms.start_location - X
	delta_x := delta[0]

	if delta_x < 0 {
		delta_x = -delta_x
	}
	// Small motion ops
	if int(button) == 1 {
		if delta_x < 10 {
			// control-left-mouse => raise the track
			if ks.control_key_down {
				v.raise_track(X)
			} else if ks.shift_key_down {
				v.move_track(X)
			} else {
				v.toggle_event_select(X)
			}
		} else {
			// zoom
			v.mouse_zoom_event(X)
		}
	} else if int(button) == 4 {
		// mouse wheel scroll up
	} else if int(button) == 5 {
		// mouse scroll down
	}
	ms.active = false
	v.w.Widget().SetCursor(v.default_cursor)
	v.repaint()
}

func motion_notify_event(w gtk.Widget, o gtk.Opaque) {
	v := &g2_main.v
	ms := &v.ms

	if ms.active {
		m := o.EventMotion()
		X := m.GetX()
		v.ms.current_location = X
		v.repaint()
	}
}

func vscroll_changed(w gtk.Widget, o gtk.Opaque) {
	v := &g2_main.v
	v.g.first_track_index = uint(v.vscroll_adjustment.GetValue())
	v.repaint()
}

func hscroll_changed(w gtk.Widget, o gtk.Opaque) {
	v := &g2_main.v
	current_width := v.g.maxvistime - v.g.minvistime
	v.g.minvistime = uint(v.hscroll_adjustment.GetValue())
	v.g.maxvistime = v.g.minvistime + current_width
	v.repaint()
}

func (v *view) recompute_hscroll() {
	fc := &g2_main.current_file
	current_width := float64(v.g.maxvistime - v.g.minvistime)

	last_event_index := int(fc.events.Elts()) - 1
	if last_event_index < 0 {
		return
	}
	last_event := fc.GetEvent(last_event_index)

	value := float64(v.g.minvistime)
	lower := float64(0)
	step_increment := current_width / 6.0
	page_increment := step_increment * 3.0
	upper := float64(last_event.time) + page_increment

	v.hscroll_adjustment.Reconfigure(value, lower, upper,
		step_increment, page_increment, current_width)
}

func (v *view) recompute_vscroll() {
	fc := &g2_main.current_file

	last_track_index := int(fc.bound_tracks.Elts()) - 1

	value := float64(v.g.first_track_index)
	lower := float64(0)
	upper := float64(last_track_index + 1)
	step_increment := float64(last_track_index) / 6.0
	page_increment := step_increment * 3.0

	v.vscroll_adjustment.Reconfigure(value, lower, upper,
		step_increment, page_increment, float64(v.g.ntracks))
}

func get_search_event_code(s string) {
	v := &g2_main.v
	in := std.NewParseInput(s)
	var tmp int

	v.g.search_code_set = false
	for !in.End() {
		switch {
		case in.Parse("%d", &tmp):
			v.g.search_code_set = true
			v.g.search_code = uint32(tmp)
		default:
			goto doublebreak
		}
	}
doublebreak:
	in.Free()
}

func (v *view) search_button(ask_for_event bool, anomaly_search bool) {
	fc := &g2_main.current_file

	if ask_for_event {
		default_string := string("0")
		if v.g.search_code_set {
			default_string = std.Format("%d", int(v.g.search_code))
		}
		v.g.search_code_set = false
		modal_dialog("Search", "Event to find", default_string,
			get_search_event_code)

		free(default_string)

		if !v.g.search_code_set {
			message_box("Search Error", "Please supply an event index")
			return
		}
	} else {
		if !v.g.search_code_set {
			std.Logf("No Search Code Set...\n")
			return
		}
	}

	// Deselect the previous result, if it's actually selected
	if v.g.search_index_valid {
		event := fc.GetEvent(int(v.g.search_index))
		if event.flags&EVENT_FLAG_SEARCH_RESULT != 0 {
			event.flags ^= EVENT_FLAG_SEARCH_RESULT
		}
	}

	if ask_for_event && anomaly_search {
		v.compute_anomaly_stats()
	}

	nevents := int(fc.events.Elts())

	// Start searching from the minimum visible event if the
	// search position is invalid
	if !v.g.search_index_valid {
		// $$$ two-dimensional search window
		v.g.search_index = uint(v.find_event_index(v.g.minvistime))
		v.g.search_index_valid = true
	} else {
		// Start searching from the next / previous index
		if v.g.search_forward {
			v.g.search_index++
			if v.g.search_index >= uint(nevents) {
				v.g.search_index = 0
			}
		} else {
			if v.g.search_index == 0 {
				v.g.search_index = uint(nevents - 1)
			} else {
				v.g.search_index--
			}
		}
	}

	if v.g.search_code > uint32(fc.event_definitions.Elts()) {
		s := std.Format("Event Index %d Out of Range", v.g.search_code)
		message_box("Error", s)
		free(s)
		v.g.search_code = 0
		return
	}

	ed := &fc.event_definitions.Vec[v.g.search_code]

	if !ed.is_displayed {
		std.Logf("event %d's aren't displayed...\n", v.g.search_code)
		return
	}

	for i := 0; i < nevents; i++ {
		var event_index int
		if v.g.search_forward {
			event_index = int(v.g.search_index) + i
			if event_index >= nevents {
				event_index -= nevents
			}
		} else {
			event_index = int(v.g.search_index) - i
			if event_index < 0 {
				event_index += nevents
			}
		}
		event := fc.GetEvent(event_index)

		if event.code != v.g.search_code {
			continue
		}
		// See if the event in question looks like an anomaly
		if anomaly_search {
			a_valid, a_track, a_value := g2_main.ef.ElogGetAnomalyData(event_index, v.g.search_code)
			if !a_valid {
				panic("WTF wrong event code!")
			}
			if a_value < v.anomaly_threshold_by_track[a_track] {
				continue
			}
		}

		// found event, mark it and 2d-scroll there (if not visible)
		event.flags |= EVENT_FLAG_SEARCH_RESULT
		track_index := uint(fc.track_display_map[event.track_index])

		// Need a vertical (track) scroll to show the result?
		if track_index < v.g.first_track_index ||
			track_index >= v.g.first_track_index+v.g.ntracks {
			v.g.first_track_index = track_index
			v.recompute_vscroll()
		}
		// Need a horizontal scroll to show the result?
		if event.time < uint64(v.g.minvistime) ||
			event.time > uint64(v.g.maxvistime) {
			current_width := v.g.maxvistime - v.g.minvistime
			v.g.minvistime = uint(event.time)
			v.g.maxvistime = uint(event.time) + uint(current_width)
			v.recompute_hscroll()
		}
		v.g.search_index = uint(event_index)
		break
	}
	v.repaint()
}

func (v *view) compute_zoom_delta() (current_width, zoom_delta uint) {
	current_width = v.g.maxvistime - v.g.minvistime
	zoom_delta = current_width / 6
	if zoom_delta == 0 {
		zoom_delta = 3
	}
	return
}

func button_click(w gtk.Widget, o gtk.Opaque) {
	v := &g2_main.v
	fc := &g2_main.current_file

	button := uint(o)

	current_width, zoom_delta := v.compute_zoom_delta()

	switch button {
	case FILE_BUTTON:
		select_elog_file()

	case VPP_LIVE_BUTTON:
		if open_elog_file("[vpp live log]") {
			g2_main.v.w.Destroy()
			g2_main.view_init(g2_main.app)
			v.repaint()
		}

	case ZOOMIN_BUTTON:
		v.g.minvistime += zoom_delta
		v.g.maxvistime -= zoom_delta
		v.recompute_hscroll()

	case ZOOMOUT_BUTTON:
		if v.g.minvistime >= zoom_delta {
			v.g.minvistime -= zoom_delta
			v.g.maxvistime += zoom_delta
		} else {
			v.g.minvistime = 0
			v.g.maxvistime += zoom_delta * 2
		}
		v.recompute_hscroll()

	case BOTTOM_BUTTON:
		first_track_to_display := int(fc.bound_tracks.Elts())
		first_track_to_display -= int(v.g.ntracks)

		if first_track_to_display < 0 {
			v.g.first_track_index = uint(0)
		} else {
			v.g.first_track_index = uint(first_track_to_display)
		}
		v.recompute_vscroll()

	case TOP_BUTTON:
		v.g.first_track_index = 0
		v.recompute_vscroll()

	case SUMMARY_BUTTON:
		if v.g.summary_mode {
			return
		}
		v.g.summary_mode = true
		v.summary_button.Widget.Hide()
		v.no_summary_button.Widget.Show()

	case NO_SUMMARY_BUTTON:
		if !v.g.summary_mode {
			return
		}
		v.g.summary_mode = false
		v.no_summary_button.Widget.Hide()
		v.summary_button.Widget.Show()

	case MORE_TRACES_BUTTON:
		if (v.g.strip_height*2)/3 <= 15 {
			return
		}
		v.g.strip_height = (v.g.strip_height * 2) / 3
		v.g.event_offset = v.g.strip_height - 15

		v.g.ntracks = (v.g.draw_height - v.g.time_ax_height) / v.g.strip_height
		v.recompute_vscroll()

	case LESS_TRACES_BUTTON:
		v.g.strip_height = (v.g.strip_height * 3) / 2
		v.g.event_offset = v.g.strip_height - 15
		v.g.ntracks = (v.g.draw_height - v.g.time_ax_height) / v.g.strip_height
		v.recompute_vscroll()

	case START_BUTTON:
		v.g.minvistime = 0
		v.g.maxvistime = current_width
		v.recompute_hscroll()

	case END_BUTTON:
		n_events := fc.events.Elts()
		last_event := &fc.events.Vec[n_events-1]
		v.g.maxvistime = uint(last_event.time)
		v.g.minvistime = 0
		if last_event.time >= uint64(current_width) {
			v.g.minvistime = uint(last_event.time - uint64(current_width))
		}
		v.recompute_hscroll()

	case SEARCH_BUTTON:
		v.search_button(true /* ask for event code */, false /* anomaly mode */)

	case SEARCH_AGAIN_BUTTON:
		v.search_button(false /* search again */, false /* anomaly mode */)

	case ANOMALY_BUTTON:
		v.search_button(true /* ask for event code */, true /* anomaly mode */)

	case ANOMALY_NEXT_BUTTON:
		v.search_button(false /* ask for event code */, true /* anomaly mode */)

	case FORWARD_BUTTON:
		if v.g.search_forward {
			return
		}
		v.g.search_forward = true
		v.forward_button.Widget.Hide()
		v.backward_button.Widget.Show()

	case BACKWARD_BUTTON:
		if !v.g.search_forward {
			return
		}
		v.g.search_forward = false
		v.backward_button.Widget.Hide()
		v.forward_button.Widget.Show()

	case SNAP_BUTTON:
		v.make_snapshot()
	case NEXT_BUTTON:
		v.next_snapshot()
	case DEL_BUTTON:
		v.delete_snapshot()
	default:
		std.Logf("button %d clicked\n", button)
	}
	v.repaint()
}

func key_press_event(w gtk.Widget, o gtk.Opaque) {
	v := &g2_main.v
	e := o.EventKey()
	sym := e.Sym()
	truestr := "true"
	falsestr := "false"

	if false {
		std.Logf("press key %d\n", int(sym))
	}

	switch int(sym) {
	case 65507:
		v.ks.control_key_down = true
	case 65505:
		v.ks.shift_key_down = true

	case 'd':
		v.delete_snapshot()

	case 'e':
		//Toggle event summary mode
		if v.g.summary_mode {
			v.g.summary_mode = false
			v.summary_button.Widget.Show()
			v.no_summary_button.Widget.Hide()
		} else {
			v.g.summary_mode = true
			v.no_summary_button.Widget.Show()
			v.summary_button.Widget.Hide()
		}
		v.repaint()

	case 'g':
		s := std.Format(" minvistime: %d\n", v.g.minvistime)
		s += std.Format(" maxvistime: %d\n", v.g.maxvistime)
		s += std.Format(" first_track_index: %d\n", v.g.first_track_index)
		s += std.Format(" ntracks: %d\n", v.g.ntracks)
		s += std.Format(" draw_width: %d\n", v.g.draw_width)
		s += std.Format(" draw_height: %d\n", v.g.draw_height)
		s += std.Format(" track_ax_width: %d\n", v.g.track_ax_width)
		s += std.Format(" time_ax_height: %d\n", v.g.time_ax_height)
		s += std.Format(" time_ax_spacing: %d\n", v.g.time_ax_spacing)
		s += std.Format(" strip_height: %d\n", v.g.strip_height)
		s += std.Format(" pop_offset: %d\n", v.g.pop_offset)
		s += std.Format(" event_offset: %d\n", v.g.event_offset)
		s += std.Format(" search_code: %d\n", int(v.g.search_code))
		tfs := truestr
		if !v.g.search_code_set {
			tfs = falsestr
		}
		s += std.Format(" search_code_set: %v\n", tfs)
		s += std.Format(" search_index: %d\n", v.g.search_index)

		tfs = truestr
		if !v.g.search_index_valid {
			tfs = falsestr
		}
		s += std.Format(" search_index_valid: %v\n", tfs)

		tfs = truestr
		if !v.g.search_forward {
			tfs = falsestr
		}
		s += std.Format(" search_forward: %v\n", tfs)
		sms := "false"
		if v.g.summary_mode {
			sms = "true"
		}
		s += std.Format(" summary_mode: %s\n", sms)
		if v.ms.active {
			s += std.Format(" mouse state: button %d start (%d, %d) current (%d, %d)\n",
				v.ms.which_button,
				int(v.ms.start_location[0]),
				int(v.ms.start_location[1]),
				int(v.ms.current_location[0]),
				int(v.ms.current_location[1]))
		}
		if v.ks.control_key_down {
			s += std.Format(" keyboard: control key down\n")
		}
		if v.ks.shift_key_down {
			s += std.Format(" keyboard: shift key down\n")
		}
		message_box("View Geometry", s)

	case 'i':
		_, zoom_delta := v.compute_zoom_delta()
		v.g.minvistime += zoom_delta
		v.g.maxvistime -= zoom_delta
		v.recompute_hscroll()
		v.repaint()

	case 'l':
		runtime.Heap.ShowTrace(10)

	case 'n':
		v.next_snapshot()

	case 'o':
		_, zoom_delta := v.compute_zoom_delta()
		if v.g.minvistime >= zoom_delta {
			v.g.minvistime -= zoom_delta
			v.g.maxvistime += zoom_delta
		} else {
			v.g.minvistime = 0
			v.g.maxvistime += zoom_delta * 2
		}
		v.recompute_hscroll()
		v.repaint()

	case 'q':
		g2_main.v.w.Destroy()
		g2_main.ef.ElogQuit(w, o)

	case 's':
		v.make_snapshot()

	case 't':
		v.memory_trace_enable = !v.memory_trace_enable
		runtime.Heap.TraceEnable(v.memory_trace_enable)

	default:
	}
}

func key_release_event(w gtk.Widget, o gtk.Opaque) {
	v := &g2_main.v
	e := o.EventKey()
	sym := e.Sym()

	if false {
		std.Logf("release key %d\n", int(sym))
	}

	switch int(sym) {
	case 65507:
		v.ks.control_key_down = false
	case 65505:
		v.ks.shift_key_down = false
	}
}

func (v *view) time_per_pixel() (rv float64) {
	rv = float64(v.g.maxvistime-v.g.minvistime) /
		float64(v.g.draw_width-v.g.track_ax_width)
	return
}

func draw_time_axis(v *view, w gtk.Widget, c gtk.CairoContext) {

	y := float64(v.g.ntracks*v.g.strip_height + v.g.event_offset)
	x := float64(v.g.track_ax_width)
	nticks := (v.g.draw_width - v.g.track_ax_width) / v.g.time_ax_spacing
	time_per_pixel := v.time_per_pixel()

	units := "ns"
	unit_divisor := 1.0
	maxvistime := float64(v.g.maxvistime)

	if maxvistime/unit_divisor > 1000.0 {
		units = "us"
		unit_divisor = 1000.0
	}
	if maxvistime/unit_divisor > 1000.0 {
		units = "ms"
		unit_divisor = 1000.0 * 1000.0
	}
	if maxvistime/unit_divisor > 1000.0 {
		units = "s"
		unit_divisor = 1000.0 * 1000.0 * 1000.0
	}

	start := gtk.X{x, y}
	end := gtk.X{float64(v.g.draw_width), y}

	c.Moveto(start)
	c.Lineto(end)
	c.Stroke()

	start += gtk.X{0, -6}
	end = start + gtk.X{0, +9}

	xoffset := uint(0)

	for i := uint(0); i < nticks; i++ {
		c.Moveto(start)
		c.Lineto(end)
		c.Stroke()

		time := x + float64(xoffset) - float64(v.g.track_ax_width)
		time *= time_per_pixel
		time += float64(v.g.minvistime)
		time /= unit_divisor

		s := std.Format("%.2f%s", time, units)

		c.TextAt(gtk.X{x + float64(xoffset), y + 15.0},
			gtk.JustifyCenter, s)
		free(s)

		start += gtk.X{float64(v.g.time_ax_spacing), 0}
		end += gtk.X{float64(v.g.time_ax_spacing), 0}
		xoffset += v.g.time_ax_spacing
	}

}

func draw_track_axis(v *view, w gtk.Widget, c gtk.CairoContext) {
	f := &g2_main.current_file
	if f.Initialized == false {
		return
	}

	for i := uint(0); i < f.bound_tracks.Elts(); i++ {
		track := &f.bound_tracks.Vec[i]

		if uint(track.display_index) < v.g.first_track_index ||
			uint(track.display_index) >= v.g.first_track_index+v.g.ntracks {
			continue
		}
		scrolled_display_index := uint(track.display_index) -
			v.g.first_track_index

		s := track.track_str
		y := scrolled_display_index*v.g.strip_height + v.g.event_offset
		label_tick := 0.0
		c.TextAt(gtk.X{0.0, float64(y)}, gtk.JustifyLeft, s)
		label_tick = 4.0
		c.Moveto(gtk.X{float64(v.g.track_ax_width) - label_tick, float64(y)})
		c.Lineto(gtk.X{float64(v.g.draw_width), float64(y)})
	}
	c.Stroke()
}

func (v *view) find_event_index(t uint) int {
	fc := &g2_main.current_file
	var index, bottom, top uint

	time := uint64(t)

	bottom = fc.events.Elts() - 1
	top = 0

	for {
		index = (bottom + top) / 2

		event := fc.GetEvent(int(index))

		if event.time == time {
			return int(index)
		}

		if top >= bottom {
			for index > 0 && event.time > time {
				index--
				event = fc.GetEvent(int(index))
			}
			for index < fc.events.Elts() && event.time < time {
				index++
				event = fc.GetEvent(int(index))
			}
			return int(index)
		}

		if event.time < time {
			top = index + 1
		} else {
			bottom = index - 1
		}
	}
}

type decoration struct {
	bg gtk.Color
}

var standardColors = [...]decoration{
	decoration{ // dark blue
		bg: gtk.Rgb(.05, .24, .34),
	},
	decoration{ // red
		bg: gtk.Rgb(.85, .31, .12),
	},
	decoration{
		bg: gtk.Rgb(.92, .78, .27),
	},
	decoration{ // orange
		bg: gtk.Rgb(.94, .55, .17),
	},
	decoration{ // light blue
		bg: gtk.Rgb(.07, .47, .60),
	},
	decoration{ // teal
		bg: gtk.Rgb(.36, .65, .58),
	},
	decoration{
		bg: gtk.Rgb(.64, .72, .42),
	},
	decoration{ // dark blue
		bg: gtk.Rgb(.06, .36, .47),
	},
	decoration{ // light blue
		bg: gtk.Rgb(.07, .58, .73),
	},
	decoration{ // yellow
		bg: gtk.Rgb(.93, .67, .22),
	},
	decoration{ // orange
		bg: gtk.Rgb(.95, .42, .13),
	},
	decoration{ // red
		bg: gtk.Rgb(.75, .18, .11),
	},
}

func set_pattern(c gtk.CairoContext, x, dx gtk.X, bg gtk.Color, f float64) {
	p := gtk.NewPatternLinear(x, x+gtk.X{0, dx[1]})
	p.AddColorStop(0, bg.Lighten(f))
	p.AddColorStop(1, bg.Darken(f))
	c.SetSource(p)
}

func (v *view) event_box(e *Event, c gtk.CairoContext, X gtk.X, s string) (r rectangle) {
	set_font_and_line_width(c)

	r = rectangle{}

	strs := newline_string_slice(s)

	r.init_for_string(X, strs)

	d := decoration{bg: gtk.Gray(.25) + .8*gtk.Alpha}
	if e != nil {
		d = standardColors[int(e.code)%len(standardColors)]
	}

	// Splat down a filled white rectangle, 50% alpha
	width_comma_height := gtk.X{
		r.upper_right[0] - r.upper_left[0],
		r.lower_left[1] - r.upper_left[1],
	}

	c.Save()

	c.SetOperator(gtk.OperatorOver)
	bg := d.bg.Lighten(.5)
	set_pattern(c, r.upper_left, width_comma_height, bg+.9*gtk.Alpha, .1)
	radius := 3.
	c.RoundedRectangle(r.upper_left, width_comma_height, radius)
	c.Fill()

	// Paint the text black, 100% alpha
	c.SetSourceColor(gtk.Black)

	fe := c.FontExtents()

	if false {
		// Starting point offset, so the top of the first line is at the stated
		// y-coordinate

		X += gtk.X{0, fe.Height / 2}

		for i := range strs {
			c.TextAt(X, gtk.JustifyCenter, "%v", strs[i])
			X += gtk.X{0, fe.Height}
		}
	} else {
		lines := makes([]text_line, len(strs))
		for i := range lines {
			lines[i].s = strs[i]
		}
		X += gtk.X{0, fe.Height / 2}

		my_text(c, X, text_align_center, lines)
	}

	free(strs)
	c.Stroke()

	c.Restore()
	return
}

const (
	text_align_center = iota
	text_align_left
	text_align_right
)

type text_line struct {
	s string
	e gtk.TextExtents
}

func my_text_box(c gtk.CairoContext, lines []text_line) (bounding_box gtk.X) {
	fe := c.FontExtents()
	max_width := float64(0)
	for i := range lines {
		te := c.TextExtents(lines[i].s)
		lines[i].e = te
		if w := te.Size[0]; w > max_width {
			max_width = w
		}
	}
	bounding_box = gtk.X{max_width, fe.Height * float64(len(lines))}
	return
}

func my_text(c gtk.CairoContext, x gtk.X, text_align int, lines []text_line) gtk.X {
	var a float64
	switch text_align {
	case text_align_center:
		a = .5
	case text_align_left:
		a = 0
	case text_align_right:
		a = 1
	}
	fe := c.FontExtents()
	bounding_box := my_text_box(c, lines)
	y0 := fe.Ascent - .5*fe.Height*float64(len(lines))
	for i := range lines {
		x1 := x + gtk.X{-lines[i].e.Size[0]*a - lines[i].e.Bearing[0], y0 + float64(i)*fe.Height}
		c.Moveto(x1)
		c.Text(lines[i].s)
	}
	return bounding_box
}

func (v *view) flag_box(event *Event, c gtk.CairoContext, X gtk.X, end gtk.X, s string) (r rectangle) {
	// up half a strip from the current paint coordinate
	flagX := X + gtk.X{0, -float64(v.g.strip_height) / 2.0}

	r = v.event_box(event, c, flagX, s)

	midpt_x := (r.upper_left[0] + r.upper_right[0]) / 2.0

	// Start of line @ midpoint_x, bottom of bounding box
	line_start_X := gtk.X{midpt_x, r.lower_left[1]}

	// If the boxes overlap (tall event pop-up) don't draw the line at all
	if line_start_X[1] >= end[1] {
		return
	}
	c.Moveto(line_start_X)
	c.Lineto(end)
	c.Stroke()
	return
}

type selected_event struct {
	event    *Event
	where    gtk.X
	end      gtk.X
	bounds   rectangle
	contents string
}

func walk_event_data(v *view, w gtk.Widget, c gtk.CairoContext, mouse_hit gtk.X, toggle_select bool) bool {

	fc := &g2_main.current_file
	if fc.Initialized == false {
		return false
	}
	time_per_pixel := v.time_per_pixel()

	start_index := v.find_event_index(v.g.minvistime)

	if start_index >= int(fc.events.Elts()) {
		return false
	}

	last_used_x := makes([]uint, v.g.ntracks)
	selected_events_by_track := makes([][]selected_event, v.g.ntracks)

	for ei := start_index; ei < int(fc.events.Elts()); ei++ {
		event := fc.GetEvent(ei)

		if event.time > uint64(v.g.maxvistime) {
			break
		}

		// If the event isn't displayed, we're done
		ed := &fc.event_definitions.Vec[event.code]
		if !ed.is_displayed {
			continue
		}

		// Track out of range?
		track_index := uint(fc.track_display_map[event.track_index])
		if track_index < v.g.first_track_index ||
			track_index >= v.g.first_track_index+v.g.ntracks {
			continue
		}

		track_index -= v.g.first_track_index
		x := v.g.track_ax_width +
			uint(float64(event.time-uint64(v.g.minvistime))/time_per_pixel)
		y := track_index*v.g.strip_height + v.g.event_offset

		has_event_flag := event.flags&
			(EVENT_FLAG_SEARCH_RESULT|EVENT_FLAG_SELECT) != 0

		// Dont scribble over the same pixels
		if x <= last_used_x[track_index] && !has_event_flag {
			continue
		}

		// Tag with "Search Result" or formatted event?
		if has_event_flag {
			// Render the event at (0,0), collect opaque data to paint it
			r, o := g2_main.ef.ElogFileRenderSelectedEvent(event.pool_index)
			// Translate the bounding rectangle to the current location
			where := gtk.X{float64(x), float64(y)}
			r.translate(where)
			selected_events_by_track[track_index] = appends(selected_events_by_track[track_index], selected_event{
				where:    where,
				end:      where,
				bounds:   r,
				contents: o,
				event:    event})
		}

		if v.g.summary_mode {
			// Draw events as vertical line segments
			delta := v.g.strip_height / 4
			if delta == 0 {
				delta++
			}
			y = track_index*v.g.strip_height + v.g.event_offset
			if !toggle_select {
				c.Moveto(gtk.X{float64(x), float64(y - delta)})
				c.Lineto(gtk.X{float64(x), float64(y + delta)})
				c.Stroke()
			} else {
				r := rectangle{
					upper_left:  gtk.X{float64(x), float64(y - delta)},
					lower_left:  gtk.X{float64(x), float64(y + delta)},
					upper_right: gtk.X{float64(x + 3), float64(y - delta)},
					lower_right: gtk.X{float64(x + 3), float64(y + delta)},
				}
				if r.contains(mouse_hit) {
					if (event.flags & EVENT_FLAG_SEARCH_RESULT) != 0 {
						event.flags ^= EVENT_FLAG_SEARCH_RESULT
						for i := range selected_events_by_track {
							for j := range selected_events_by_track[i] {
								free(selected_events_by_track[i][j].contents)
							}
						}
						return true
					}
					event.flags ^= EVENT_FLAG_SELECT
					for i := range selected_events_by_track {
						for j := range selected_events_by_track[i] {
							free(selected_events_by_track[i][j].contents)
						}
					}
					return true
				}
			}
			last_used_x[track_index] = x
		} else {
			// Draw events as boxed numbers
			s := std.Format("%d", event.code)
			if !toggle_select {
				r := v.event_box(event, c, gtk.X{float64(x), float64(y)}, s)
				last_used_x[track_index] = uint(r.upper_right[0]) + 2
			} else {
				r := rectangle{}
				strs := newline_string_slice(s)
				r.init_for_string(gtk.X{float64(x), float64(y)}, strs)
				free(strs)

				if r.contains(mouse_hit) {
					if (event.flags & EVENT_FLAG_SEARCH_RESULT) != 0 {
						event.flags ^= EVENT_FLAG_SEARCH_RESULT
						for i := range selected_events_by_track {
							for j := range selected_events_by_track[i] {
								free(selected_events_by_track[i][j].contents)
							}
						}
						free(s)
						return true
					}
					// Deselect the previous search result
					if v.g.search_index_valid {
						event := fc.GetEvent(int(v.g.search_index))
						if event.flags&EVENT_FLAG_SEARCH_RESULT != 0 {
							event.flags ^= EVENT_FLAG_SEARCH_RESULT
						}
					}
					// Search from here...
					v.g.search_index = uint(ei)
					v.g.search_code = event.code
					v.g.search_code_set = true
					v.g.search_index_valid = true
					event.flags ^= EVENT_FLAG_SELECT
					free(s)
					for i := range selected_events_by_track {
						for j := range selected_events_by_track[i] {
							free(selected_events_by_track[i][j].contents)
						}
					}
					return true
				}
			}
			free(s)
		}
	}

	// Place selected events at suitable x-coordinates, right here

	for track := range selected_events_by_track {
		if len(selected_events_by_track[track]) == 0 {
			continue
		}
		selected_events := selected_events_by_track[track]

		start_index = len(selected_events) / 2
		for place_index := start_index; place_index > 0; place_index-- {
			cur := &selected_events[place_index]
			left := &selected_events[place_index-1]

			if left.bounds.upper_right[0] > cur.bounds.upper_left[0] {
				dx := gtk.X{2 + left.bounds.upper_right[0] -
					cur.bounds.upper_left[0], 0}
				new_where := left.where - dx
				if new_where[0] > 0 {
					left.bounds.upper_left -= dx
					left.bounds.lower_left -= dx
					left.bounds.upper_right -= dx
					left.bounds.lower_right -= dx
					left.where = new_where
				}
			}
		}

		for place_index := start_index; place_index < len(selected_events)-1; place_index++ {
			cur := &selected_events[place_index]
			right := &selected_events[place_index+1]

			if right.bounds.upper_left[0] < cur.bounds.upper_right[0] {
				dx := gtk.X{2 + cur.bounds.upper_right[0] - right.bounds.upper_left[0],
					0}
				new_where := right.where + dx
				// not quite the right condition
				if new_where[0] < float64(v.g.draw_width) {
					right.bounds.upper_left += dx
					right.bounds.lower_left += dx
					right.bounds.upper_right += dx
					right.bounds.lower_right += dx
					right.where = new_where
				}
			}
		}

		// Paint the selected events

		for i := range selected_events {
			se := &selected_events[i]
			if !toggle_select {
				g2_main.ef.ElogFilePaintSelectedEvent(se, c)
				free(se.contents)
			} else {
				r := &rectangle{}
				boxX := se.where + gtk.X{0, -float64(v.g.strip_height) / 2.0}
				boxX += gtk.X{0, -4}
				strs := newline_string_slice(se.contents)
				r.init_for_string(boxX, strs)
				free(se.contents)
				free(strs)
				if r.contains(mouse_hit) {
					for j := i + 1; j < len(selected_events); j++ {
						free(selected_events[j].contents)
					}
					if (se.event.flags & EVENT_FLAG_SEARCH_RESULT) != 0 {
						se.event.flags ^= EVENT_FLAG_SEARCH_RESULT
						return true
					}
					se.event.flags ^= EVENT_FLAG_SELECT
					return true
				}
			}
		}
	}
	return false
}

func draw_event_data(v *view, w gtk.Widget, c gtk.CairoContext) {
	_ = walk_event_data(v, w, c, gtk.X{}, false /* toggle_select */)
}

func draw_mouse_hints(v *view, w gtk.Widget, c gtk.CairoContext) {
	ms := &v.ms
	ks := &v.ks

	// No press-move-release sequence in progress
	if !ms.active || ks.control_key_down || ks.shift_key_down {
		return
	}

	abs_dx := float64(ms.start_location[0]) - float64(ms.current_location[0])
	if abs_dx < 0.0 {
		abs_dx = -abs_dx
	}

	// Don't draw the hint if the mouse is right where we started
	if abs_dx < 4 {
		return
	}

	mp := &g2_main
	fc := &mp.current_file

	displayable_tracks := fc.bound_tracks.Elts() - v.g.first_track_index
	if displayable_tracks > v.g.ntracks {
		displayable_tracks = v.g.ntracks
	}

	// Draw the box a bit below the actual mouse hit, so the cursor
	// doesn't impinge on the string in the box
	box_location := ms.current_location + gtk.X{0, 6}

	if ms.which_button == 3 || ms.which_button == 1 {
		X := gtk.X{ms.start_location[0], 0}
		c.Moveto(X)
		X = gtk.X{ms.start_location[0], box_location[1]}
		c.Lineto(X)
		X = gtk.X{box_location[0], 0}
		c.Moveto(X)
		X = gtk.X{box_location[0], box_location[1]}
		c.Lineto(X)

		time_per_pixel := v.time_per_pixel()

		delta_pixels := ms.start_location - ms.current_location
		dp := delta_pixels[0]
		if dp < 0.0 {
			dp = -dp
		}
		dt := dp * time_per_pixel * 1e-9
		var s string

		if dt >= 1.0 {
			s = std.Format("%.2fs", dt)
		} else if dt >= 1e-3 {
			s = std.Format("%.2fms", dt*1e3)
		} else if dt >= 1e-6 {
			s = std.Format("%.2fus", dt*1e6)
		} else {
			s = std.Format("%.2fns", dt*1e9)
		}
		c.Stroke()
		v.event_box(nil, c, box_location, s)
		free(s)
	}
}

// Draws a box-with-X 10 pixels inside the draw-area dimensions
func draw_test_pattern(v *view, w gtk.Widget, c gtk.CairoContext) {
	ul := gtk.X{10, 10}
	ll := gtk.X{10, float64(v.g.draw_height - 10)}
	lr := gtk.X{float64(v.g.draw_width - 10), float64(v.g.draw_height - 10)}
	ur := gtk.X{float64(v.g.draw_width - 10), 10}
	c.Moveto(ul)
	c.Lineto(ll)
	c.Lineto(lr)
	c.Lineto(ur)
	c.Lineto(ul)
	c.Lineto(lr)
	c.Moveto(ll)
	c.Lineto(ur)
	c.Stroke()
}

func da_draw(w gtk.Widget, o gtk.Opaque) {
	v := &g2_main.v
	c := o.Cairo()

	size := w.Size()

	if (!v.current_surface_set) || (v.current_surface_size[0] != size[0]) ||
		(v.current_surface_size[1] != size[1]) {
		if v.current_surface_set {
			v.current_surface.Destroy()
		}
		v.current_surface = w.CreateSimilarSurface(gtk.CairoContentColor,
			w.Size())
		v.current_surface_size = w.Size()
		c.SetSourceSurface(v.current_surface, 0)
		set_font_and_line_width(c)
		v.current_surface_set = true
	}
	set_font_and_line_width(c)

	if false {
		draw_test_pattern(v, w, c)
	}

	draw_track_axis(v, w, c)
	draw_time_axis(v, w, c)
	draw_event_data(v, w, c)
	draw_mouse_hints(v, w, c)
	c.Stroke()
}

func file_read_callback(mp *g2_main_t) {
	v := &mp.v
	fc := &mp.current_file

	v.g.first_track_index = 0
	n_events := fc.events.Elts()

	if n_events == 0 {
		std.Logf("WARNING: no event data?")
		return
	}

	v.g.minvistime = 0
	last_event := &fc.events.Vec[n_events-1]
	v.g.maxvistime = uint((last_event.time * 9) / 8)
	v.g.track_ax_width = uint(fc.WidestTrackString * 12)

	// Single event? make display 1 second wide...
	if n_events == 1 {
		v.g.maxvistime = 1000000
	}
	v.w.SetTitle(fc.file_name)

	v.recompute_hscroll()
	v.recompute_vscroll()
	v.event_selector_init()
}

func (v *view) MakeCursors(w gtk.Window) {
	d := gtk.DefaultDisplay()
	v.zoom_cursor = d.CursorFromName("zoom-in")
	v.time_ruler_cursor = d.CursorFromName("crosshair")
	v.grabbing_cursor = d.CursorFromName("grabbing")
	v.move_cursor = d.CursorFromName("move")
	v.default_cursor = d.CursorFromName("default")
}

func (mp *g2_main_t) view_init(app gtk.Application) {
	v := &mp.v

	// Default drawing area size derived from monitor size
	d := gtk.DefaultDisplay()
	m := d.PrimaryMonitor()
	z := .6 * m.Geometry().Size
	v.g.draw_width = uint(z[0])
	v.g.draw_height = uint(z[1])
	// $$$$ FIXME: read yaml / git-config or something
	if false {
		v.g.draw_width = 2500
		v.g.draw_height = 1800
	}
	v.g.track_ax_width = 80
	v.g.time_ax_spacing = 100
	v.g.strip_height = 65
	v.g.time_ax_height = v.g.strip_height
	v.g.pop_offset = 20
	v.g.event_offset = v.g.strip_height - 15
	/* v.first_track_index = 0 */
	v.anomaly_threshold_stddevs = 3.5
	v.g.ntracks = (v.g.draw_height - v.g.time_ax_height) / v.g.strip_height
	v.g.minvistime = 0
	v.g.maxvistime = 200
	v.g.summary_mode = true
	v.max_event_selector_lines = 20
	v.current_snapshot_index = -1
	v.snapshots = save(make([]snapshot, 0))

	if mp.current_file.Initialized {
		v.g.track_ax_width = uint(mp.current_file.WidestTrackString * 12)
	}

	// Create the main window
	w := gtk.NewWindowWithConfig(app, gtk.WindowConfig{Title: "g2"})
	v.w = w

	// Hook up event handlers
	w.Connect("configure_event", configure_event, w.Opaque())
	w.Connect("key_press_event", key_press_event, w.Opaque())
	w.Connect("key_release_event", key_release_event, w.Opaque())

	// Create and size the main drawing area
	da := gtk.NewDrawingArea()
	da.SetSize(gtk.X{float64(v.g.draw_width), float64(v.g.draw_height)})

	da.Connect("draw", da_draw)
	da.Connect("button_press_event", button_press_event, da.Opaque())
	da.Connect("button_release_event", button_release_event, da.Opaque())
	da.Connect("motion_notify_event", motion_notify_event, da.Opaque())
	da.Widget.SetEventMask(gtk.EventMaskButtonPress |
		gtk.EventMaskButtonRelease |
		gtk.EventMaskPointerMotion)

	// Create boxes into which we pack the peanut butter
	main_vbox := gtk.NewBox(gtk.Vertical, 0 /* spacing */)
	main_hbox := gtk.NewBox(gtk.Horizontal, 0 /* spacing */)
	vbox := gtk.NewBox(gtk.Vertical, 5 /* spacing */)
	hbox := gtk.NewBox(gtk.Horizontal, 5 /* spacing */)

	// Main drawing canvas goes into the horizontal box
	hbox.Pack(da.Widget, gtk.BoxPack{Expand: true, Fill: true})

	// Vertical scrollbar and pid axis buttons
	vmenubox := gtk.NewBox(gtk.Vertical, 5 /* spacing*/)

	v.vscroll_adjustment = gtk.NewAdjustment(gtk.AdjustmentConfig{
		Current:       0.0,
		Lo:            0.0,
		Hi:            2000.0,
		StepIncrement: 0.1,
		PageIncrement: 10.0,
		PageSize:      10.0})

	v.vscroll_adjustment.Connect("value_changed", vscroll_changed, v.vscroll_adjustment.Opaque())
	vscrollbar := gtk.NewScrollbar(gtk.Vertical, v.vscroll_adjustment)

	v.hscroll_adjustment = gtk.NewAdjustment(gtk.AdjustmentConfig{
		Current:       0.0,
		Lo:            0.0,
		Hi:            2000.0,
		StepIncrement: 0.1,
		PageIncrement: 10.0,
		PageSize:      10.0})

	v.hscroll_adjustment.Connect("value_changed", hscroll_changed,
		v.hscroll_adjustment.Opaque())
	hscrollbar := gtk.NewScrollbar(gtk.Horizontal, v.hscroll_adjustment)

	// Buttons
	top_button := gtk.NewButtonWithLabel("Top")
	top_button.Connect("clicked", button_click, TOP_BUTTON)

	bottom_button := gtk.NewButtonWithLabel("Bot")
	bottom_button.Connect("clicked", button_click, BOTTOM_BUTTON)

	more_traces_button := gtk.NewButtonWithLabel("+Tr")
	more_traces_button.Connect("clicked", button_click, MORE_TRACES_BUTTON)

	less_traces_button := gtk.NewButtonWithLabel("-Tr")
	less_traces_button.Connect("clicked", button_click, LESS_TRACES_BUTTON)

	file_button := gtk.NewButtonWithLabel("File")
	file_button.Connect("clicked", button_click, FILE_BUTTON)

	start_button := gtk.NewButtonWithLabel("Start")
	start_button.Connect("clicked", button_click, START_BUTTON)

	zoomin_button := gtk.NewButtonWithLabel("ZoomIn")
	zoomin_button.Connect("clicked", button_click, ZOOMIN_BUTTON)

	search_button := gtk.NewButtonWithLabel("Search")
	search_button.Connect("clicked", button_click, SEARCH_BUTTON)

	search_again_button := gtk.NewButtonWithLabel("Search Again")
	search_again_button.Connect("clicked", button_click, SEARCH_AGAIN_BUTTON)

	anomaly_button := gtk.NewButtonWithLabel("Anomaly")
	anomaly_button.Connect("clicked", button_click, ANOMALY_BUTTON)

	anomaly_next_button := gtk.NewButtonWithLabel("Next Anomaly")
	anomaly_next_button.Connect("clicked", button_click, ANOMALY_NEXT_BUTTON)

	zoomout_button := gtk.NewButtonWithLabel("ZoomOut")
	zoomout_button.Connect("clicked", button_click, ZOOMOUT_BUTTON)

	end_button := gtk.NewButtonWithLabel("End")
	end_button.Connect("clicked", button_click, END_BUTTON)

	snap_button := gtk.NewButtonWithLabel("Snap")
	snap_button.Connect("clicked", button_click, SNAP_BUTTON)

	next_button := gtk.NewButtonWithLabel("Next")
	next_button.Connect("clicked", button_click, NEXT_BUTTON)

	del_button := gtk.NewButtonWithLabel("Del")
	del_button.Connect("clicked", button_click, DEL_BUTTON)

	chase_event_button := gtk.NewButtonWithLabel("ChaseEvent")
	chase_event_button.Connect("clicked", button_click, CHASE_EVENT_BUTTON)

	chase_datum_button := gtk.NewButtonWithLabel("ChaseDatum")
	chase_datum_button.Connect("clicked", button_click, CHASE_DATUM_BUTTON)

	chase_track_button := gtk.NewButtonWithLabel("ChaseTrack")
	chase_track_button.Connect("clicked", button_click, CHASE_TRACK_BUTTON)

	no_chase_button := gtk.NewButtonWithLabel("NoChase")
	no_chase_button.Connect("clicked", button_click, NO_CHASE_TRACK_BUTTON)

	v.forward_button = gtk.NewButtonWithLabel("Srch->")
	v.forward_button.Connect("clicked", button_click, FORWARD_BUTTON)

	v.backward_button = gtk.NewButtonWithLabel("Srch<-")
	v.backward_button.Connect("clicked", button_click, BACKWARD_BUTTON)

	v.summary_button = gtk.NewButtonWithLabel("Summary")
	v.summary_button.Connect("clicked", button_click, SUMMARY_BUTTON)

	v.no_summary_button = gtk.NewButtonWithLabel("NoSummary")
	v.no_summary_button.Connect("clicked", button_click, NO_SUMMARY_BUTTON)

	slew_left_button := gtk.NewButtonWithLabel("<-TimeSlew")
	slew_left_button.Connect("clicked", button_click, SLEW_LEFT_BUTTON)

	slew_right_button := gtk.NewButtonWithLabel("TimeSlew->")
	slew_right_button.Connect("clicked", button_click, SLEW_RIGHT_BUTTON)

	anomaly_threshold_button := gtk.NewButtonWithLabel("Anomaly Threshold")
	anomaly_threshold_button.Connect("clicked", button_click, ANOMALY_THRESHOLD_BUTTON)
	vpp_live_button := gtk.NewButtonWithLabel("VPP-live-data")
	vpp_live_button.Connect("clicked", button_click, VPP_LIVE_BUTTON)

	// Event selection dialog packing
	vmenubox.Pack(top_button.Widget, gtk.BoxPack{})
	vmenubox.Pack(vscrollbar.Widget, gtk.BoxPack{Expand: true, Fill: true})
	vmenubox.Pack(bottom_button.Widget, gtk.BoxPack{})
	vmenubox.Pack(more_traces_button.Widget, gtk.BoxPack{})
	vmenubox.Pack(less_traces_button.Widget, gtk.BoxPack{})

	// Add scrollbar / pid selector to (the right of) the drawing area
	hbox.Pack(vmenubox.Widget, gtk.BoxPack{Fill: true})

	// First row horizontal box
	hmenubox := gtk.NewBox(gtk.Horizontal, 5 /* spacing*/)

	hmenubox.Pack(start_button.Widget, gtk.BoxPack{})
	hmenubox.Pack(hscrollbar.Widget, gtk.BoxPack{Expand: true, Fill: true})
	hmenubox.Pack(end_button.Widget, gtk.BoxPack{})

	vbox.Pack(hbox.Widget, gtk.BoxPack{Expand: true, Fill: true})
	vbox.Pack(hmenubox.Widget, gtk.BoxPack{})

	// Second row horizontal box

	hmenubox2 := gtk.NewBox(gtk.Horizontal, 5 /* spacing*/)

	hmenubox2.Pack(snap_button.Widget, gtk.BoxPack{})
	hmenubox2.Pack(next_button.Widget, gtk.BoxPack{})
	hmenubox2.Pack(del_button.Widget, gtk.BoxPack{})
	hmenubox2.Pack(chase_event_button.Widget, gtk.BoxPack{})
	hmenubox2.Pack(chase_datum_button.Widget, gtk.BoxPack{})
	hmenubox2.Pack(chase_track_button.Widget, gtk.BoxPack{})
	hmenubox2.Pack(no_chase_button.Widget, gtk.BoxPack{})
	hmenubox2.Pack(v.summary_button.Widget, gtk.BoxPack{})
	hmenubox2.Pack(v.no_summary_button.Widget, gtk.BoxPack{})
	hmenubox2.Pack(slew_left_button.Widget, gtk.BoxPack{})
	hmenubox2.Pack(slew_right_button.Widget, gtk.BoxPack{})

	vbox.Pack(hmenubox2.Widget, gtk.BoxPack{})

	// Third Row horizontal box
	hmenubox3 := gtk.NewBox(gtk.Horizontal, 5 /* spacing*/)
	hmenubox3.Pack(zoomin_button.Widget, gtk.BoxPack{})
	hmenubox3.Pack(zoomout_button.Widget, gtk.BoxPack{})
	hmenubox3.Pack(anomaly_threshold_button.Widget, gtk.BoxPack{})
	hmenubox3.Pack(anomaly_button.Widget, gtk.BoxPack{})
	hmenubox3.Pack(anomaly_next_button.Widget, gtk.BoxPack{})
	hmenubox3.Pack(v.forward_button.Widget, gtk.BoxPack{})
	hmenubox3.Pack(v.backward_button.Widget, gtk.BoxPack{})
	hmenubox3.Pack(search_button.Widget, gtk.BoxPack{})
	hmenubox3.Pack(search_again_button.Widget, gtk.BoxPack{})
	hmenubox3.Pack(vpp_live_button, gtk.BoxPack{})

	vbox.Pack(hmenubox3.Widget, gtk.BoxPack{})

	main_hbox.Pack(vbox.Widget, gtk.BoxPack{Expand: true, Fill: true})
	v.main_hbox = main_hbox
	da.Widget.CanFocus(true)
	da.Widget.GrabFocus()

	// Create the main menu bar, and menus
	menu_vbox := gtk.NewBox(gtk.Vertical, 10)
	menu_bar := gtk.NewMenuBar()
	file_menu := gtk.NewMenu()
	about_menu := gtk.NewMenu()

	menu_bar.Append(
		gtk.NewMenuItem(gtk.MenuItemConfig{
			Label:  "File",
			Parent: file_menu,
		}),
		gtk.NewMenuItem(gtk.MenuItemConfig{
			Label:  "About",
			Parent: about_menu,
		}),
	)
	menu_vbox.Pack(menu_bar, gtk.BoxPack{})

	file_menu.Append(
		gtk.NewMenuItem(gtk.MenuItemConfig{
			Label: "Open",
			Activate: func(gtk.Widget, gtk.Opaque) {
				select_elog_file()
			},
		}),

		gtk.NewMenuItem(gtk.MenuItemConfig{
			Label: "Quit",
			Activate: func(w gtk.Widget, o gtk.Opaque) {
				g2_main.v.w.Destroy()
				g2_main.ef.ElogQuit(w, o)
			},
		}),
	)
	about_menu.Append(
		gtk.NewMenuItem(gtk.MenuItemConfig{
			Label: "Version",
			Activate: func(gtk.Widget, gtk.Opaque) {
				message_box("G2 Version", "G2 Version: 0.1.0")
			},
		}),
		gtk.NewMenuItem(gtk.MenuItemConfig{
			Label: "Keyboard Shortcuts",
			Activate: func(gtk.Widget, gtk.Opaque) {
				s := "Key Function\n" +
					"--- --------\n" +
					"d   Delete Snapshot\n" +
					"e   Toggle Summary Mode\n" +
					"g   Dump view geometry parameters\n" +
					"i   Zoom In\n" +
					"l   Show Memory Leaks\n" +
					"n   Next Snapshot" +
					"o   Zoom Out\n" +
					"q   Quit\n" +
					"s   Take Snapshot\n" +
					"t   Memory Leak Trace on/off toggle\n\n" +
					"Left Mouse down...move...release Zoom\n" +
					"Control Left Mouse click Swap Tracks\n" +
					"Shift Left Mouse click Move Tracks\n" +
					"Right Mouse down...move Time Ruler\n"

				message_box("Keyboard Shortcuts", s)
				free(s)
			},
		}),
	)

	main_vbox.Pack(menu_vbox.Widget, gtk.BoxPack{})
	main_vbox.Pack(main_hbox.Widget, gtk.BoxPack{})

	w.Container().Add(main_vbox.Widget)

	if mp.current_file.Initialized {
		file_read_callback(&g2_main)
	}
	v.da = da
	v.MakeCursors(w)
	w.ShowAll()

	// Hide a few things...
	v.forward_button.Widget.Hide()
	v.g.search_forward = true
	if v.g.summary_mode {
		v.summary_button.Hide()
	} else {
		v.no_summary_button.Hide()
	}
	if !g2_main.ef.ElogFileIsLiveLog() {
		vpp_live_button.Hide()
	}
}
