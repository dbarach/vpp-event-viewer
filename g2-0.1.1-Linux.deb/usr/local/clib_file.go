//go:build ignore

package g2

// #cgo LDFLAGS: -lvppinfra
// #include <vlib/vlib.h>
// #include <vppinfra/elog.h>
import "C"

import (
	"sort"
	"std"
	"sys"
	"ui/gtk"
	"unsafe"
)

type clib_elog_main_t struct {
	memory_initialized bool
	valid              bool
	elog_main          C.elog_main_t
}

var clib_elog_main clib_elog_main_t

func get_c_str(s string) *C.char {
	b := []byte(s)
	return (*C.char)(unsafe.Pointer(&b[0]))
}

func get_elog_event_t(p unsafe.Pointer) *C.elog_event_t {
	return (*C.elog_event_t)(p)
}

func get_elog_event_time(e *C.elog_event_t) float64 {
	return *(*float64)(unsafe.Pointer(e))
}

func (cem clib_elog_main_t) ElogReadFile(clib_file string) int {
	fc := &g2_main.current_file
	cemp := &clib_elog_main
	em := &clib_elog_main.elog_main

	fc.WidestTrackString = -1

	// One-time clib memory heap initialization
	if !cemp.memory_initialized {
		C.clib_mem_init(nil, C.uword(1<<30))
		cemp.memory_initialized = true
	}

	// Throw away previous data, if any
	if cemp.valid {
		free(fc.file_name)
		fc.events.Free()

		fc.bound_tracks.Foreach(func(bt *BoundTrack) {
			free(bt.track_str)
		})
		fc.bound_tracks.Free()
		fc.event_definitions.Free()
		for k := range fc.track_display_map {
			delete(fc.track_display_map, k)
		}

		// Take a large mallet to the clib allocation arena
		C.clib_mem_destroy()
		// reinitialize allocation arena
		C.clib_mem_init(nil, C.uword(1<<30))

		// Hard reset $$$ needs leak-finder brain police
		*cemp = clib_elog_main_t{
			elog_main: C.elog_main_t{},
			valid:     false}
		g2_main.current_file = FileContents{}
		fc = &g2_main.current_file
		g2_main.ef = clib_elog_main
	}

	error := C.elog_read_file_not_inline(em, get_c_str(clib_file))

	if error != nil {
		C._clib_error_report(error)
		return 1
	}
	std.Logf("OK: read %s...\n", clib_file)

	// Build track database
	tracks := []C.elog_track_t(em.tracks, C.vec_len_not_inline(unsafe.Pointer(em.tracks)))
	for i := range tracks {
		tp := &tracks[i]

		bt := fc.bound_track_pool_get()
		// Events contain track_id + 1
		bt.track_index = i
		bt.display_index = i
		if _, ok := fc.track_display_map[i]; ok {
			std.Logf("Track code %d redefined, keep first definition...\n", i)
			fc.bound_track_pool_put(i)
			continue
		}

		bt.track_str = save(string(tp.name, C.vec_len_not_inline(unsafe.Pointer(tp.name))))
		if len(bt.track_str) > fc.WidestTrackString {
			fc.WidestTrackString = len(bt.track_str)
		}
		fc.track_display_map[bt.track_index] = bt.display_index
	}

	// Build event database
	event_types := []C.elog_event_type_t(em.event_types, C.vec_len_not_inline(unsafe.Pointer(em.event_types)))
	for i := range event_types {
		e := &event_types[i]

		event := fc.event_definitions_pool_get()
		if int(e.type_index_plus_one) <= 0 {
			panic("raw event index zero or worse")
		}
		event.event_id = int(e.type_index_plus_one) - 1
		event.is_displayed = true
		event.name = save(string(e.format, C.vec_len_not_inline(unsafe.Pointer(e.format))))
	}

	// Based on one event log, it seems like
	// the events show up sorted, but since the old viewer sorts
	// the definitions I have the feeling we'd better do it.

	sort.Sort((*evsort)(&fc.event_definitions))

	// Build events
	events := []C.elog_event_t(em.events, C.vec_len_not_inline(unsafe.Pointer(em.events)))
	starttime := get_elog_event_time(&events[0]) * 1e9

	for i := range events {
		e := &events[i]
		event_time := get_elog_event_time(e)
		event := fc.events_pool_get()
		event.time = uint64(event_time*1e9 - starttime)
		event.code = uint32(e.event_type)
		event.track_index = fc.find_or_add_track(int(e.track), i)
		event.raw_event_index = uint32(i)
	}

	// Sort tracks, rebuild map
	sort.Sort((*tracksort)(&fc.bound_tracks))
	for k := range fc.track_display_map {
		delete(fc.track_display_map, k)
	}

	for k := 0; k < int(fc.bound_tracks.Elts()); k++ {
		track := fc.GetBoundTrack(k)
		track.pool_index = k
		track.display_index = k
		fc.track_display_map[track.track_index] = track.display_index
	}
	fc.file_name = save(clib_file)

	fc.Initialized = true
	cemp.valid = true

	return 0
}

func (em clib_elog_main_t) ElogFileSupported(fn string) bool {
	elog_magic := []byte{0x0, 0x0, 0x0, 0x7, 0x65, 0x6c,
		0x6f, 0x67, 0x20, 0x76, 0x30, 0x0}

	f, e := sys.Open(fn, sys.O_RDONLY, 0)
	if e != sys.CallError(0) {
		return false
	}

	file_signature := make([]byte, len(elog_magic))

	nbytes, e := f.Read(file_signature)

	if e != sys.CallError(0) || nbytes != len(file_signature) {
		f.Close()
		return false
	}
	f.Close()

	for i := range elog_magic {
		if elog_magic[i] != file_signature[i] {
			return false
		}
	}

	return true
}

func (em clib_elog_main_t) ElogFileIsLiveLog() bool { return false }

func (em clib_elog_main_t) ElogGetAnomalyData(i int, event_code uint32) (valid bool, track int, value float64) {
	emp := &clib_elog_main.elog_main
	event := g2_main.current_file.GetEvent(i)

	raw_events := unsafe.Pointer(emp.events)
	ep := unsafe.Pointer(uintptr(raw_events) + uintptr(event.pool_index)*
		unsafe.Sizeof(C.elog_event_t{}))

	raw_event := get_elog_event_t(ep)

	if uint32(raw_event.event_type) != event_code {
		valid = false
		return
	}

	p := unsafe.Pointer(&raw_event.data)
	vp := (*C.u32)(p)

	valid = true
	track = int(raw_event.track)
	value = float64(uint32(*vp))

	return
}

func (em clib_elog_main_t) ElogFileValid() bool {
	return clib_elog_main.valid
}

func clib_event_format(i int) (s string) {
	em := &clib_elog_main.elog_main
	event := g2_main.current_file.GetEvent(i)

	events := []C.elog_event_t(em.events, C.vec_len_not_inline(unsafe.Pointer(em.events)))
	ep := &events[event.pool_index]

	if (event.flags & EVENT_FLAG_SELECT) != 0 {
		rv := C.format_one_elog_event(unsafe.Pointer(em), unsafe.Pointer(ep))
		s = save(string(rv, C.vec_len_not_inline(unsafe.Pointer(rv))))
		C.vec_free_not_inline(unsafe.Pointer(rv))
	} else {
		// Search result - save it, so we can free it...
		s = save("SearchResult")
	}

	return
}

func (cem clib_elog_main_t) ElogFileRenderSelectedEvent(event_index int) (r rectangle, s string) {
	s = clib_event_format(event_index)
	r = rectangle{}
	strs := newline_string_slice(s)
	r.init_for_string(gtk.X{}, strs)
	free(strs)
	return
}

func (cem clib_elog_main_t) ElogFilePaintSelectedEvent(se *selected_event, c gtk.CairoContext) {
	v := &g2_main.v
	v.flag_box(se.event, c, se.where, se.end, se.contents)
}

func (cem clib_elog_main_t) ElogQuit(w gtk.Widget, o gtk.Opaque) {
	g2_main.app.Quit(w, o)
}
