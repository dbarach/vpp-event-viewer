package g2

import (
	"std"
	"ui/gtk"
)

func select_elog_file() {
	parentwindow := g2_main.v.w
	dialog := gtk.NewFileChooserDialog("Please choose a file", parentwindow,
		gtk.FileChooserOpen,
		gtk.DialogButton{"Cancel", gtk.DialogResponseCancel},
		gtk.DialogButton{"Open", gtk.DialogResponseOk},
	)
	resp := dialog.Run()
	if resp == gtk.DialogResponseOk {
		if open_elog_file(dialog.Filename()) {
			g2_main.v.w.Destroy()
			g2_main.view_init(g2_main.app)
		} else {
			m := std.Format("Couldn't load %s", dialog.Filename())
			message_box("File Error", m)
		}
	}
	dialog.Destroy()
}
