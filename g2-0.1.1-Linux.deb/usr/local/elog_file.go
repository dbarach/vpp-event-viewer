package g2

import (
	"sort"
	"std"
	"sys"
	"tools/elog"
	"ui/gtk"
)

type elog_elog_main_t struct {
	valid     bool
	elog_main elog.Log
}

var elog_elog_main elog_elog_main_t

func (cem elog_elog_main_t) ElogReadFile(file string) int {
	fc := &g2_main.current_file
	cemp := &elog_elog_main

	fc.WidestTrackString = -1

	// Throw away previous data, if any
	if cemp.valid {
		free(fc.file_name)
		fc.events.Free()

		fc.bound_tracks.Foreach(func(bt *BoundTrack) {
			free(bt.track_str)
		})
		fc.bound_tracks.Free()
		fc.event_definitions.Free()
		for k := range fc.track_display_map {
			delete(fc.track_display_map, k)
		}

		// Hard reset $$$ needs leak-finder brain police
		*cemp = elog_elog_main_t{}
		g2_main.current_file = FileContents{}
		fc = &g2_main.current_file
		g2_main.ef = elog_elog_main
	}

	l := &elog_elog_main.elog_main
	error := l.Restore(file)

	if error != nil {
		std.Logf("file read error: %s\n", error.Error())
		return 1
	}
	std.Logf("OK: read %s...\n", file)

	// Build track database
	tracks := l.TrackNames()
	ntracks := len(tracks)

	for i := 0; i < ntracks; i++ {
		tp := tracks[i]
		bt := fc.bound_track_pool_get()
		// Events contain track_id + 1
		bt.track_index = i
		bt.display_index = i
		if _, ok := fc.track_display_map[i]; ok {
			std.Logf("Track code %d redefined, keep first definition...\n", i)
			fc.bound_track_pool_put(i)
			continue
		}

		bt.track_str = dup(tp)
		if len(bt.track_str) > fc.WidestTrackString {
			fc.WidestTrackString = len(bt.track_str)
		}
		fc.track_display_map[bt.track_index] = bt.display_index
	}

	// Build event database
	event_types := l.EventTypes()
	n_event_types := len(event_types)

	for i := 0; i < n_event_types; i++ {
		t := &event_types[i]

		event := fc.event_definitions_pool_get()
		event.event_id = i
		event.is_displayed = true
		event.name = t.Format
	}

	// Based on one event log, it seems like
	// the events show up sorted, but since the old viewer sorts
	// the definitions I have the feeling we'd better do it.

	sort.Sort((*evsort)(&fc.event_definitions))

	// Build events
	events := l.Events()
	n_events := len(events)

	starttime := events[0].Secs(l)

	for i := 0; i < n_events; i++ {
		e := &events[i]
		event := fc.events_pool_get()
		event.time = uint64(1e9 * (e.Secs(l) - starttime))
		event.code = uint32(e.TypeIndex())
		event.track_index = e.TrackIndex()
		event.raw_event_index = uint32(i)
	}

	// Sort tracks, rebuild map
	sort.Sort((*tracksort)(&fc.bound_tracks))
	for k := range fc.track_display_map {
		delete(fc.track_display_map, k)
	}

	for k := 0; k < int(fc.bound_tracks.Elts()); k++ {
		track := fc.GetBoundTrack(k)
		track.pool_index = k
		track.display_index = k
		fc.track_display_map[track.track_index] = track.display_index
	}
	fc.file_name = save(file)

	fc.Initialized = true
	cemp.valid = true

	return 0
}

func (cem elog_elog_main_t) ElogFileRenderSelectedEvent(event_index int) (r rectangle, s string) {
	s = elog_event_format(event_index)
	r = rectangle{}
	strs := newline_string_slice(s)
	r.init_for_string(gtk.X{}, strs)
	free(strs)
	return
}

func (cem elog_elog_main_t) ElogFilePaintSelectedEvent(se *selected_event, c gtk.CairoContext) {
	v := &g2_main.v
	v.flag_box(se.event, c, se.where, se.end, se.contents)
}

func elog_event_format(i int) (s string) {
	l := &elog_elog_main.elog_main
	event := g2_main.current_file.GetEvent(i)
	es := l.Events()
	e := &es[event.raw_event_index]

	if (event.flags & EVENT_FLAG_SELECT) != 0 {
		s = e.String(l)
	} else {
		// Search result - save it, so we can free it...
		s = save("SearchResult")
	}

	return
}

func (em elog_elog_main_t) ElogFileSupported(fn string) bool {
	if true {
		return true
	}
	f, e := sys.Open(fn, sys.O_RDONLY, 0)
	if e != sys.OK {
		return false
	}
	defer f.Close()

	file_signature := make([]byte, 64)
	nbytes, e := f.Read(file_signature)
	if e != sys.OK || nbytes != len(file_signature) {
		return false
	}
	return elog.IsSavedLog(file_signature)
}

func (em elog_elog_main_t) ElogFileIsLiveLog() bool { return false }

func (em elog_elog_main_t) ElogGetAnomalyData(i int, event_code uint32) (valid bool, track int, value float64) {
	event := g2_main.current_file.GetEvent(i)
	l := &elog_elog_main.elog_main
	es := l.Events()
	e := &es[event.raw_event_index]
	if valid = uint32(e.TypeIndex()) == event_code; valid {
		track = e.TrackIndex()
		value = float64(*(*uint32)(e.Ptr()))
	}
	return
}

func (em elog_elog_main_t) ElogFileValid() bool {
	return elog_elog_main.valid
}

func (em elog_elog_main_t) ElogQuit(w gtk.Widget, o gtk.Opaque) {
	g2_main.app.Quit(w, o)
}
